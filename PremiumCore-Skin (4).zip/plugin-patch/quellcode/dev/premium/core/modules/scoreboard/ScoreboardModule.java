package dev.premium.core.modules.scoreboard;

import dev.premium.core.PremiumCore;
import dev.premium.core.module.PluginModule;
import dev.premium.core.util.Legacy;
import dev.premium.core.util.Skin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import io.papermc.paper.scoreboard.numbers.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

public final class ScoreboardModule
implements PluginModule,
Listener {
    /** Modernes Standard-Design (greift auch bei alter config.yml ohne scoreboard.version: 2). */
    static final String DEFAULT_TITLE = "&#FFB300&l\u2694 &#FFD54F&l%server_name% &#FFB300&l\u2694";
    static final List<String> DEFAULT_LINES = List.of(
            "&a$ &fGeld &a&l%money_short%",
            "&e\u2605 &fLevel &e&l%level%",
            "&c\u2694 &fKills &a&l%kills_fmt%",
            "&4\u2620 &fTode &a&l%deaths_fmt%",
            "&6\u265b &fClan &6&l%clan%",
            "&d\u26a1 &fPing &b%ping%ms",
            "&b\u231b &fKeyall &b&l%keyall%",
            "&a\u231a &fSpielzeit &e&l%playtime%",
            "&7 ",
            "&9\u2726 &fXP &a%xp%&7/&a%xp_needed%",
            "&f\u2764 &fOnline &a%online%&7/&a%max%",
            "&c&l%server_ip%");
    private PremiumCore plugin;
    private final Map<UUID, Board> boards = new HashMap<UUID, Board>();

    @Override
    public String id() {
        return "scoreboard";
    }

    @Override
    public void enable(PremiumCore plugin) {
        this.plugin = plugin;
        if (!plugin.getConfig().getBoolean("scoreboard.enabled", true)) {
            return;
        }
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)plugin);
        long ticks = Math.max(5L, plugin.getConfig().getLong("scoreboard.update-ticks", 20L));
        Bukkit.getScheduler().runTaskTimer((Plugin)plugin, () -> Bukkit.getOnlinePlayers().forEach(this::update), 20L, ticks);
        Bukkit.getOnlinePlayers().forEach(this::update);
    }

    @Override
    public void disable() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!this.boards.containsKey(p.getUniqueId())) continue;
            p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        }
        this.boards.clear();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> this.update(event.getPlayer()), 10L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        this.boards.remove(event.getPlayer().getUniqueId());
    }

    private void update(Player player) {
        int i;
        String title;
        if (!player.isOnline()) {
            return;
        }
        Board board = this.boards.computeIfAbsent(player.getUniqueId(), id -> new Board());
        if (player.getScoreboard() != board.scoreboard) {
            player.setScoreboard(board.scoreboard);
        }
        if (Skin.enabled() && this.plugin.getConfig().getBoolean("scoreboard.skin", true)) {
            this.updateSkin(player, board);
            return;
        }
        boolean modern = this.plugin.getConfig().getInt("scoreboard.version", 1) >= 3;
        String rawTitle = modern ? this.plugin.getConfig().getString("scoreboard.title", DEFAULT_TITLE) : DEFAULT_TITLE;
        if (!(title = this.plugin.placeholders().apply(player, rawTitle)).equals(board.lastTitle)) {
            board.objective.displayName(Legacy.parse(title));
            board.lastTitle = title;
        }
        List<String> raw = new ArrayList<String>(modern ? this.plugin.getConfig().getStringList("scoreboard.lines") : DEFAULT_LINES);
        // Die Zeile mit der Server-IP steht immer ganz unten, egal wie die Zeilen in der config.yml sortiert sind
        List<String> ipLines = new ArrayList<String>();
        for (String l : raw) {
            if (l.contains("%server_ip%")) {
                ipLines.add(l);
            }
        }
        if (!ipLines.isEmpty()) {
            raw.removeAll(ipLines);
            while (raw.size() + ipLines.size() > 15 && !raw.isEmpty()) {
                raw.remove(raw.size() - 1);
            }
            raw.addAll(ipLines);
        }
        int size = Math.min(15, raw.size());
        ArrayList<String> lines = new ArrayList<String>(size);
        for (i = 0; i < size; ++i) {
            String line = this.translateLabels(player, (String)raw.get(i));
            lines.add(this.plugin.placeholders().apply(player, this.custom(player, line)));
        }
        if (board.teams.size() != size) {
            this.rebuild(board, size);
        }
        for (i = 0; i < size; ++i) {
            if (board.last.size() > i && board.last.get(i).equals(lines.get(i))) continue;
            board.teams.get(i).prefix(Legacy.parse((String)lines.get(i)));
            if (board.last.size() <= i) {
                board.last.add((String)lines.get(i));
                continue;
            }
            board.last.set(i, (String)lines.get(i));
        }
    }

    private record Row(char icon, String de, String en, String value) {
    }

    /** Linker Innenrand im Rahmen (Pixel) und Breite des Rahmen-Glyphs (148 px + 1). */
    private static final int LP = 10;
    private static final int FRAME_W = 149;

    /** Resourcepack-Design: eigene Icons, Werte in einer Spalte, Trennlinien zwischen den Gruppen. */
    private void updateSkin(Player player, Board board) {
        boolean en = dev.premium.core.i18n.Tr.en(player);
        List<Row> rows = new ArrayList<Row>();
        rows.add(new Row(Skin.ICON_COIN, "Geld", "Money", "&a&l%money_short%"));
        rows.add(new Row(Skin.ICON_STAR, "Level", "Level", "&e&l%level%"));
        rows.add(new Row(Skin.ICON_GEM, "XP", "XP", "&a%xp%&7/&a%xp_needed%"));
        rows.add(null);
        rows.add(new Row(Skin.ICON_SWORD, "Kills", "Kills", "&a&l%kills_fmt%"));
        rows.add(new Row(Skin.ICON_SKULL, "Tode", "Deaths", "&c&l%deaths_fmt%"));
        rows.add(new Row(Skin.ICON_CROWN, "Clan", "Clan", "&6&l%clan%"));
        rows.add(null);
        rows.add(new Row(Skin.ICON_KEY, "Keyall", "Key All", "&b&l%keyall%"));
        rows.add(new Row(Skin.ICON_CLOCK, "Spielzeit", "Playtime", "&e&l%playtime%"));
        rows.add(new Row(Skin.ICON_SIGNAL, "Ping", "Ping", "&b%ping%&7ms"));
        rows.add(null);
        rows.add(new Row(Skin.ICON_PEOPLE, "Online", "Online", "&a%online%&7/&a%max%"));
        int labelW = 0;
        for (Row r : rows) {
            if (r != null) {
                labelW = Math.max(labelW, Skin.width(en ? r.en() : r.de()));
            }
        }
        int valueX = LP + 10 + 3 + labelW + 1 + 5;
        List<Component> lines = new ArrayList<Component>();
        for (Row r : rows) {
            if (r == null) {
                lines.add(Component.text("").append(Skin.space(LP)).append(Skin.glyph(Skin.DIVIDER)));
                continue;
            }
            String label = en ? r.en() : r.de();
            String value = this.plugin.placeholders().apply(player, this.custom(player, r.value()));
            int labelX = LP + 10 + 3;
            lines.add(Component.text("").append(Skin.space(LP)).append(Skin.glyph(r.icon())).append(Skin.space(10 - Skin.iconAdvance(r.icon()) + 3))
                    .append(Component.text(label, NamedTextColor.GRAY)).append(Skin.space(valueX - labelX - (Skin.width(label) + 1)))
                    .append(Legacy.parse(value)));
        }
        String ip = "&c&l%server_ip%";
        for (String l : this.plugin.getConfig().getStringList("scoreboard.lines")) {
            if (l.contains("%server_ip%")) {
                ip = l;
            }
        }
        lines.add(Component.text("").append(Skin.space(LP)).append(Legacy.parse(this.plugin.placeholders().apply(player, ip))));
        // Titel: Server-Name zwischen zwei Schwert-Icons
        String rawTitle = this.plugin.getConfig().getString("scoreboard.title", DEFAULT_TITLE);
        String t = this.plugin.placeholders().apply(player, rawTitle).replace("\u2694", "").trim();
        if (!t.equals(board.lastTitle)) {
            // Titel = Rahmen-Glyph (148 px) + Servername zentriert im Banner; Gesamtbreite = Rahmenbreite, damit die Sidebar so breit wird
            Component name = Legacy.parse(t);
            String plain = net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText().serialize(name);
            int w = Skin.width(plain) + plain.length();   // fett: +1 px je Zeichen
            int x = Math.max(0, (FRAME_W - w) / 2);
            int rest = Math.max(0, FRAME_W - x - w);
            board.objective.displayName(Skin.glyph(Skin.FRAME).append(Skin.space(-FRAME_W + x)).append(name).append(Skin.space(rest)));
            board.lastTitle = t;
        }
        int size = Math.min(15, lines.size());
        if (board.teams.size() != size) {
            this.rebuild(board, size);
        }
        for (int i = 0; i < size; ++i) {
            String key = lines.get(i).toString();
            if (board.last.size() > i && board.last.get(i).equals(key)) {
                continue;
            }
            board.teams.get(i).prefix(lines.get(i));
            if (board.last.size() <= i) {
                board.last.add(key);
            } else {
                board.last.set(i, key);
            }
        }
    }

    private String translateLabels(Player player, String line) {
        if (!dev.premium.core.i18n.Tr.en(player)) {
            return line;
        }
        return line.replace("Geld", "Money")
                .replace("Tode", "Deaths")
                .replace("Spielzeit", "Playtime")
                .replace("Keyall", "Key All");
    }

    /** Zusaetzliche Scoreboard-Platzhalter: %money_short% (326.35M), %kills_fmt%, %deaths_fmt% (3,690), %keyall% (5m 35s). */
    private String custom(Player player, String line) {
        if (line.indexOf('%') < 0) {
            return line;
        }
        dev.premium.core.data.PlayerData data = this.plugin.players().getIfLoaded(player.getUniqueId());
        double money = data != null ? data.balance() : 0.0;
        int kills = data != null ? data.kills() : 0;
        int deaths = data != null ? data.deaths() : 0;
        String key = this.plugin.services().get(dev.premium.core.modules.keyall.KeyAllModule.class).map(k -> k.countdown()).orElse("-");
        int online = dev.premium.core.service.PlaceholderService.onlineCount();
        int max = this.plugin.placeholders().maxPlayers();
        String on = String.valueOf(online);
        String mx = String.valueOf(max);
        return line.replace("%online%", on).replace("%online_players%", on).replace("%max%", mx).replace("%max_players%", mx)
                .replace("%money_short%", shortMoney(money))
                .replace("%kills_fmt%", String.format(java.util.Locale.US, "%,d", kills))
                .replace("%deaths_fmt%", String.format(java.util.Locale.US, "%,d", deaths))
                .replace("%keyall%", key);
    }

    /** 326350000 -> 326.35M, 1500 -> 1.5K, 999 -> 999 */
    static String shortMoney(double v) {
        double a = Math.abs(v);
        String[] suffix = {"", "K", "M", "B", "T"};
        int i = 0;
        double x = a;
        while (x >= 1000.0 && i < suffix.length - 1) {
            x /= 1000.0;
            ++i;
        }
        String num = new java.text.DecimalFormat(i == 0 ? "0.##" : "0.##", java.text.DecimalFormatSymbols.getInstance(java.util.Locale.US)).format(x);
        return (v < 0 ? "-" : "") + num + suffix[i];
    }

    private void rebuild(Board board, int size) {
        for (Team team : board.teams) {
            team.unregister();
        }
        for (Object entry : new ArrayList(board.scoreboard.getEntries())) {
            board.scoreboard.resetScores((String)entry);
        }
        board.teams.clear();
        board.last.clear();
        for (int i = 0; i < size; ++i) {
            Object entry;
            entry = "\u00a7" + Integer.toHexString(i) + "\u00a7r";
            Team team = board.scoreboard.getTeam("l" + i);
            if (team == null) {
                team = board.scoreboard.registerNewTeam("l" + i);
            }
            team.addEntry((String)entry);
            board.objective.getScore((String)entry).setScore(size - i);
            board.teams.add(team);
        }
    }

    private static final class Board {
        final Scoreboard scoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
        final Objective objective;
        final List<Team> teams = new ArrayList<Team>();
        final List<String> last = new ArrayList<String>();
        String lastTitle = "";

        Board() {
            this.objective = this.scoreboard.registerNewObjective("pc", "dummy", Legacy.parse("PremiumCore"));
            this.objective.setDisplaySlot(DisplaySlot.SIDEBAR);
            this.objective.numberFormat(NumberFormat.blank());
        }
    }
}
