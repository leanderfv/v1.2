package dev.premium.core.modules.auction;

import dev.premium.core.PremiumCore;
import dev.premium.core.gui.Gui;
import dev.premium.core.gui.Interactive;
import dev.premium.core.util.Fmt;
import dev.premium.core.util.ItemBuilder;
import dev.premium.core.util.Skin;
import dev.premium.core.util.ItemValue;
import dev.premium.core.util.Sfx;
import dev.premium.core.util.TextUtil;
import dev.premium.core.util.Ui;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

/**
 * Schritt 1 der Auktions-Erstellung: Das Item kommt in den Slot in der Mitte - per Shift-Klick auf ein Item im
 * eigenen Inventar (geht direkt in die Mitte) oder per Klick mit dem Item am Cursor. Es passt genau EIN Stack
 * hinein; ist der Slot belegt, passiert bei weiteren Klicks nichts. Danach öffnet sich das Amboss-Menü für den Preis.
 */
public final class CreateAuctionGui extends Gui implements Interactive {
    static final int ITEM_SLOT = 13;
    private final AuctionModule module;
    private final Gui parent;
    private boolean proceeding;
    private ItemStack held;

    public CreateAuctionGui(PremiumCore plugin, AuctionModule module, Gui parent) {
        super(plugin, Ui.auction("Auktion erstellen"), 4);
        this.module = module;
        this.parent = parent;
    }

    private static boolean empty(ItemStack s) {
        return s == null || s.getType().isAir();
    }

    private void deny(Player player) {
        Sfx.ERROR.play(player);
        this.plugin.msg().err((CommandSender) player, "Es passt nur <white>ein Item<red> hinein – nimm das aktuelle zuerst heraus.", new TagResolver[0]);
    }

    private void later(Player player) {
        Bukkit.getScheduler().runTask((Plugin) this.plugin, () -> {
            if (player.isOnline()) {
                player.updateInventory();
                this.changed(player);
            }
        });
    }

    // ------------------------------------------------------------------ Interaktion (alles manuell, nichts geht verloren)

    @Override
    public boolean allowClick(Player player, InventoryClickEvent event) {
        int raw = event.getRawSlot();
        int top = this.getInventory().getSize();
        Inventory inv = this.getInventory();
        if (raw < 0 || event.getAction() == InventoryAction.COLLECT_TO_CURSOR) {
            return false;
        }
        if (raw >= top) {
            // Klick im eigenen Inventar
            if (event.isShiftClick()) {
                ItemStack clicked = event.getCurrentItem();
                if (!empty(clicked)) {
                    if (empty(inv.getItem(ITEM_SLOT))) {
                        inv.setItem(ITEM_SLOT, clicked.clone());
                        Inventory own = event.getClickedInventory();
                        if (own != null) {
                            own.setItem(event.getSlot(), null);
                        }
                        Sfx.CLICK.play(player);
                        this.later(player);
                    } else {
                        this.deny(player);
                    }
                }
                return false;
            }
            return true;
        }
        if (raw != ITEM_SLOT) {
            return false; // Buttons und Rahmen: GuiManager ruft handleClick auf
        }
        ItemStack cursor = player.getItemOnCursor();
        ItemStack inSlot = inv.getItem(ITEM_SLOT);
        if (event.isShiftClick()) {
            if (!empty(inSlot)) {
                inv.setItem(ITEM_SLOT, null);
                Ui.give(player, inSlot);
                this.later(player);
            }
        } else if (empty(cursor) && !empty(inSlot)) {
            inv.setItem(ITEM_SLOT, null);
            player.setItemOnCursor(inSlot);
            this.later(player);
        } else if (!empty(cursor) && empty(inSlot)) {
            if (event.isRightClick()) {
                ItemStack one = cursor.clone();
                one.setAmount(1);
                inv.setItem(ITEM_SLOT, one);
                cursor.setAmount(cursor.getAmount() - 1);
                player.setItemOnCursor(cursor.getAmount() > 0 ? cursor : null);
            } else {
                inv.setItem(ITEM_SLOT, cursor.clone());
                player.setItemOnCursor(null);
            }
            this.later(player);
        } else if (!empty(cursor) && !empty(inSlot)) {
            this.deny(player);
        }
        return false;
    }

    @Override
    public boolean allowDrag(Player player, InventoryDragEvent event) {
        int top = this.getInventory().getSize();
        for (int raw : event.getRawSlots()) {
            if (raw < top) {
                return false;
            }
        }
        return true;
    }

    @Override
    public void changed(Player player) {
        if (player.isOnline() && player.getOpenInventory().getTopInventory() == this.getInventory()) {
            this.refresh(player);
            // Sobald ein Item im Slot liegt, öffnet sich sofort die Preis-Eingabe
            if (!this.proceeding && !empty(this.getInventory().getItem(ITEM_SLOT))) {
                this.proceed(player);
            }
        }
    }

    /** Behält das abgelegte Item beim Neuzeichnen. */
    @Override
    public void refresh(Player viewer) {
        ItemStack keep = this.getInventory().getItem(ITEM_SLOT);
        this.held = keep;
        super.refresh(viewer);
        this.getInventory().setItem(ITEM_SLOT, keep);
    }

    @Override
    public void onClose(Player player) {
        if (this.proceeding) {
            return;
        }
        ItemStack item = this.getInventory().getItem(ITEM_SLOT);
        if (!empty(item)) {
            this.getInventory().setItem(ITEM_SLOT, null);
            this.module.giveBack(player, item);
            this.plugin.msg().info((CommandSender) player, "Auktion abgebrochen – dein Item liegt wieder im Inventar.", new TagResolver[0]);
        }
    }

    // ------------------------------------------------------------------ Darstellung

    @Override
    protected void render(Player viewer) {
        this.border(Ui.FRAME);
        ItemStack item = this.held != null ? this.held : this.getInventory().getItem(ITEM_SLOT);
        boolean has = !empty(item);

        this.set(4, ItemBuilder.of(Material.GOLD_BLOCK).name("<aqua><bold>Auktion erstellen")
                .lore("<gray>1. Item in den Slot legen", "<gray>   <dark_gray>(Shift-Klick auf dein Item)", "<gray>2. Preis im Amboss eingeben", "<gray>3. Fertig!").glow().build());

        this.set(11, ItemBuilder.of(Material.HOPPER).name("<yellow><bold>Item aus der Hand nehmen")
                .lore("<gray>Legt das Item deiner Haupthand", "<gray>in den Auktions-Slot.", "", "<yellow>▶ Klicken").build(), e -> {
            ItemStack cur = this.getInventory().getItem(ITEM_SLOT);
            if (!empty(cur)) {
                this.deny(viewer);
                return;
            }
            ItemStack hand = viewer.getInventory().getItemInMainHand();
            if (hand.getType().isAir()) {
                this.plugin.msg().err((CommandSender) viewer, "Du hältst kein Item in der Hand.", new TagResolver[0]);
                Sfx.ERROR.play(viewer);
                return;
            }
            this.getInventory().setItem(ITEM_SLOT, hand.clone());
            viewer.getInventory().setItemInMainHand(null);
            this.changed(viewer);
        });

        int max = this.plugin.getConfig().getInt("auction.max-listings", 8);
        long mine = this.module.ownedBy(viewer.getUniqueId()).stream().filter(a -> a.status == 0).count();
        this.set(15, ItemBuilder.of(Material.BOOK).name("<white><bold>Infos")
                .lore("<gray>Laufzeit: <white>" + this.plugin.getConfig().getLong("auction.duration-hours", 48L) + " Stunden",
                        "<gray>Gebühr: <white>" + Fmt.number(this.plugin.getConfig().getDouble("auction.tax-percent", 5.0)) + "%",
                        "<gray>Deine Auktionen: <white>" + mine + "<dark_gray>/" + max).build());

        if (has) {
            double value = this.plugin.prices().value(item.getType()) * item.getAmount();
            this.set(22, Skin.btn("arrow_right", ItemBuilder.of(Material.LIME_CONCRETE).name("<green><bold>Weiter → Preis festlegen")
                    .lore("<gray>Item: <white>" + item.getAmount() + "x " + TextUtil.pretty(item.getType()),
                            "<gray>Marktwert: <green>" + ItemValue.fmt(value),
                            "",
                            "<yellow>▶ Klicken, dann Preis im Amboss eingeben").glow().build()), e -> this.proceed(viewer));
        } else {
            this.set(22, Skin.btn("arrow_right_off", ItemBuilder.of(Material.GRAY_CONCRETE).name("<gray><bold>Weiter → Preis festlegen")
                    .lore("<red>Lege zuerst ein Item in den", "<red>Slot in der Mitte.").build()));
        }
        this.backButton(31, this.parent != null ? this.parent : new AuctionGui(this.plugin, this.module));

        // Alle übrigen Slots (außer dem Item-Slot) belegen, damit nichts anderes hineingelegt werden kann.
        ItemStack filler = Ui.pane();
        for (int i = 0; i < this.getInventory().getSize(); ++i) {
            if (i != ITEM_SLOT && this.getInventory().getItem(i) == null) {
                this.getInventory().setItem(i, filler);
            }
        }
    }

    private void proceed(Player viewer) {
        ItemStack item = this.getInventory().getItem(ITEM_SLOT);
        if (empty(item)) {
            return;
        }
        if (this.proceeding || !this.module.canList(viewer)) {
            return;
        }
        ItemStack taken = ItemValue.strip(item.clone());
        this.getInventory().setItem(ITEM_SLOT, null);
        this.proceeding = true;
        this.module.askPrice(viewer, taken);
    }
}
