package dev.premium.core.modules.auction;

import dev.premium.core.PremiumCore;
import dev.premium.core.gui.ConfirmGui;
import dev.premium.core.gui.Gui;
import dev.premium.core.util.AnvilPrompt;
import dev.premium.core.util.Fmt;
import dev.premium.core.util.ItemBuilder;
import dev.premium.core.util.ItemValue;
import dev.premium.core.util.Msg;
import dev.premium.core.util.Skin;
import dev.premium.core.util.TextUtil;
import dev.premium.core.util.Ui;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class AuctionGui extends Gui {
    private final AuctionModule module;
    private Sort sort = Sort.NEWEST;
    private boolean rareOnly;
    private String search = "";
    private int page;

    public AuctionGui(PremiumCore plugin, AuctionModule module) {
        super(plugin, Ui.auction("Auktionshaus"), 6);
        this.module = module;
    }

    @Override
    protected Skin.Layout layout() {
        return Skin.Layout.BAR;
    }

    private List<Auction> view() {
        List<Auction> list = this.module.active();
        if (this.rareOnly) {
            list.removeIf(a -> !a.rare);
        }
        if (!this.search.isBlank()) {
            String q = this.search.toLowerCase(Locale.ROOT);
            list.removeIf(a -> !a.item.getType().name().toLowerCase(Locale.ROOT).replace('_', ' ').contains(q) && !a.sellerName.toLowerCase(Locale.ROOT).contains(q));
        }
        Comparator<Auction> cmp;
        switch (this.sort) {
            case PRICE_ASC:
                cmp = Comparator.comparingDouble(a -> a.price);
                break;
            case PRICE_DESC:
                cmp = Comparator.comparingDouble((Auction a) -> a.price).reversed();
                break;
            case ENDING:
                cmp = Comparator.comparingLong(a -> a.expires);
                break;
            default:
                cmp = Comparator.comparingLong((Auction a) -> a.created).reversed();
        }
        list.sort(cmp);
        return list;
    }

    @Override
    protected void render(Player viewer) {
        List<Auction> list = this.view();
        int pages = Math.max(1, (int) Math.ceil((double) list.size() / 45.0));
        this.page = Math.min(this.page, pages - 1);
        for (int i = 0; i < 45; ++i) {
            int index = this.page * 45 + i;
            if (index >= list.size()) break;
            final Auction a = list.get(index);
            boolean own = a.seller.equals(viewer.getUniqueId());
            this.set(i, display(a, own ? "<red>▶ Klicken zum Abbrechen" : "<green>▶ Klicken zum Kaufen"), e -> {
                if (own) {
                    new ConfirmGui(this.plugin, "<red><bold>Auktion abbrechen", List.of("<gray>Item zurück ins Inventar?"), p -> {
                        this.module.reclaim(p, a.id);
                        new AuctionGui(this.plugin, this.module).open(p);
                    }, p -> this.open(p)).open(viewer);
                } else {
                    new ConfirmGui(this.plugin, "<green><bold>Kauf bestätigen", List.of("<white>" + a.item.getAmount() + "x " + TextUtil.pretty(a.item.getType()), "<gray>Preis: <gold>" + Fmt.money(a.price), "<gray>Dein Geld: <gold>" + Fmt.money(this.plugin.economy().balance((OfflinePlayer) viewer))), p -> {
                        this.module.buy(p, a.id);
                        new AuctionGui(this.plugin, this.module).open(p);
                    }, p -> this.open(p)).open(viewer);
                }
            });
        }
        if (list.isEmpty()) {
            this.set(22, ItemBuilder.of(Material.BARRIER).name("<red>Keine Auktionen gefunden")
                    .lore("<gray>Klicke unten rechts auf", "<green>Create Auction<gray>, um etwas zu verkaufen.").build());
        }
        ItemStack pane = Ui.pane();
        for (int slot = 45; slot < 54; ++slot) {
            this.set(slot, pane);
        }
        this.set(45, Skin.btn("search", ItemBuilder.of(Material.COMPASS).name("<aqua><bold>Suche")
                .lore(this.search.isBlank() ? "<gray>Nach Item oder Verkäufer suchen" : "<gray>Aktiv: <white>" + Msg.esc(this.search), "",
                        "<yellow>▶ Klicken zum Suchen", "<red>Rechtsklick: <white>Filter löschen").build()), e -> {
            if (e.isRightClick()) {
                this.search = "";
                this.page = 0;
                this.refresh(viewer);
                return;
            }
            AnvilPrompt.get(this.plugin).ask(viewer, Ui.auction("Auktionen suchen"), "Item oder Spielername", null,
                    t -> t.length() > 40 ? List.of("!Zu lang") : List.of("Suche: " + Msg.esc(t)),
                    t -> {
                        this.search = t;
                        this.page = 0;
                        this.open(viewer);
                    }, () -> this.open(viewer));
        });
        Sort next = Sort.values()[(this.sort.ordinal() + 1) % Sort.values().length];
        this.set(46, Skin.btn("filter", ItemBuilder.of(Material.CLOCK).name("<yellow><bold>Sortierung")
                .lore("<gray>Aktuell: <white>" + this.sort.label, "", "<yellow>▶ Klicken zum Wechseln").build()), e -> {
            this.sort = next;
            this.page = 0;
            this.refresh(viewer);
        });
        ItemBuilder rare = ItemBuilder.of(Material.NETHER_STAR).name("<light_purple><bold>Seltene Items")
                .lore(this.rareOnly ? "<green>Filter aktiv" : "<gray>Nur wertvolle Items zeigen", "", "<yellow>▶ Klicken");
        this.set(47, (this.rareOnly ? rare.glow() : rare).build(), e -> {
            this.rareOnly = !this.rareOnly;
            this.page = 0;
            this.refresh(viewer);
        });
        if (this.page > 0) {
            this.set(48, Skin.btn("prev", ItemBuilder.of(Material.SPECTRAL_ARROW).name("<green>« Zurück").build()), e -> {
                --this.page;
                this.refresh(viewer);
            });
        }
        this.set(49, Skin.btn("orders", ItemBuilder.of(Material.CHEST).name("<gold><bold>Meine Auktionen")
                .lore("<gray>Seite <yellow>" + (this.page + 1) + "<gray>/<yellow>" + pages + " <dark_gray>· <gray>" + list.size() + " Angebote", "", "<yellow>▶ Klicken").build()),
                e -> new MyAuctionsGui(this.plugin, this.module, this, viewer.getUniqueId()).open(viewer));
        if (this.page < pages - 1) {
            this.set(50, Skin.btn("next", ItemBuilder.of(Material.SPECTRAL_ARROW).name("<green>Weiter »").build()), e -> {
                ++this.page;
                this.refresh(viewer);
            });
        }
        this.set(51, ItemBuilder.of(Material.BOOK).name("<white><bold>Kaufhistorie")
                .lore("<gray>Deine letzten Käufe/Verkäufe", "", "<yellow>▶ Klicken").build(), e -> new HistoryGui(this.plugin, this.module, this).open(viewer));
        this.set(52, Ui.balance(this.plugin, viewer));
        // Unten rechts: Auktion erstellen
        this.set(53, Skin.btn("plus", ItemBuilder.of(Material.EMERALD_BLOCK).name("<green><bold>+ Create Auction")
                .lore("<gray>Item hineinlegen und danach den", "<gray>Preis im Amboss eingeben.", "<gray>Z. B. <white>1000<gray>, <white>1k<gray>, <white>10k<gray>, <white>100m",
                        "", "<yellow>▶ Klicken zum Erstellen").glow().build()),
                e -> new CreateAuctionGui(this.plugin, this.module, this).open(viewer));
    }

    /** Anzeige einer Auktion (ohne automatische Wert-Lore, dafür mit Marktwert). */
    static ItemStack display(Auction a, String action) {
        PremiumCore plugin = PremiumCore.getPlugin(PremiumCore.class);
        ItemStack stack = ItemValue.strip(a.item.clone());
        ItemMeta meta = stack.getItemMeta();
        List<Component> current = meta.lore();
        ArrayList<Component> lore = current != null ? new ArrayList<Component>(current) : new ArrayList<Component>();
        lore.add(Component.empty());
        lore.add(Msg.item("<gray>Preis: <green><bold>" + Fmt.money(a.price)));
        lore.add(Msg.item("<gray>Marktwert: <white>" + Fmt.money(plugin.prices().value(a.item.getType()) * a.item.getAmount())));
        lore.add(Msg.item("<gray>Verkäufer: <white>" + Msg.esc(a.sellerName)));
        long left = Math.max(0L, a.expires - System.currentTimeMillis());
        lore.add(Msg.item("<gray>Endet in: <white>" + AuctionModule.remaining(left)));
        if (a.rare) {
            lore.add(Msg.item("<light_purple>⭐ Seltenes Item"));
        }
        if (action != null) {
            lore.add(Component.empty());
            lore.add(Msg.item(action));
        }
        meta.lore(lore);
        stack.setItemMeta(meta);
        return stack;
    }

    private enum Sort {
        NEWEST("Neueste"),
        PRICE_ASC("Preis ↑"),
        PRICE_DESC("Preis ↓"),
        ENDING("Endet bald");

        final String label;

        Sort(String label) {
            this.label = label;
        }
    }
}
