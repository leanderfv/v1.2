package dev.premium.core.modules.orders;

import dev.premium.core.PremiumCore;
import dev.premium.core.gui.Gui;
import dev.premium.core.util.ItemBuilder;
import dev.premium.core.util.Skin;
import dev.premium.core.util.Msg;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.entity.Player;

/** "Item auswählen": 4x9 Items, unten Zurück, Suche, Vorherige/Nächste Seite. Ein Klick startet Anzahl -> Preis -> Bestätigung. */
public final class ItemSelectGui extends Gui {
    private static final int ITEMS = 36;

    private final OrdersModule orders;
    private final Gui back;
    private String search = "";
    private int page;

    public ItemSelectGui(PremiumCore plugin, OrdersModule orders, Gui back) {
        super(plugin, orders.title("select"), 5);
        this.orders = orders;
        this.back = back;
    }

    @Override
    protected Skin.Layout layout() {
        return Skin.Layout.BAR;
    }

    @Override
    protected void render(Player viewer) {
        List<Material> list = this.orders.catalog(this.search);
        int pages = Math.max(1, (list.size() + ITEMS - 1) / ITEMS);
        this.page = Math.max(0, Math.min(this.page, pages - 1));
        for (int i = 0; i < ITEMS; ++i) {
            int index = this.page * ITEMS + i;
            if (index >= list.size()) {
                break;
            }
            final Material material = list.get(index);
            this.set(i, ItemBuilder.of(material).name("<white>" + OrdersModule.itemTag(material)).lore("<yellow>▶ Klicken zum Auswählen").build(),
                    e -> this.orders.startCreate(viewer, material, this));
        }
        if (list.isEmpty()) {
            this.set(13, ItemBuilder.of(Material.BARRIER).name("<red>Kein Item gefunden").build());
        }
        this.set(36, Skin.btn("back", ItemBuilder.of(this.orders.button("back", Material.ARROW)).name("<gray><bold>Zurück").build()), e -> this.back.open(viewer));
        List<String> searchLore = new ArrayList<>();
        if (!this.search.isEmpty()) {
            searchLore.add("<gray>Aktuell: <white>" + Msg.esc(this.search));
            searchLore.add("<dark_gray>Rechtsklick: Suche löschen");
        } else {
            searchLore.add("<gray>Nach einem Item suchen");
        }
        this.set(37, Skin.btn("search", ItemBuilder.of(this.orders.button("search", Material.SPYGLASS)).name("<red><bold>Suche").lore(searchLore).build()), e -> {
            if (e.isRightClick()) {
                this.search = "";
                this.page = 0;
                this.refresh(viewer);
                return;
            }
            this.orders.prompt(viewer, "Suche eingeben", "z. B. Birke", t -> List.of("Suche: " + t), text -> {
                this.search = text.trim();
                this.page = 0;
                this.open(viewer);
            }, () -> this.open(viewer));
        });
        final int lastPage = pages - 1;
        this.set(39, Skin.btn("prev", ItemBuilder.of(this.orders.button("previous", Material.ARROW)).name("<aqua><bold>Vorherige Seite").lore("<gray>Seite " + (this.page + 1) + "/" + pages).build()), e -> {
            if (this.page > 0) {
                --this.page;
            }
            this.refresh(viewer);
        });
        this.set(41, Skin.btn("next", ItemBuilder.of(this.orders.button("next", Material.ARROW)).name("<aqua><bold>Nächste Seite").lore("<gray>Seite " + (this.page + 1) + "/" + pages).build()), e -> {
            if (this.page < lastPage) {
                ++this.page;
            }
            this.refresh(viewer);
        });
    }
}
