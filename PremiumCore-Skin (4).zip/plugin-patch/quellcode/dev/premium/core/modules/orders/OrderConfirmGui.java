package dev.premium.core.modules.orders;

import dev.premium.core.PremiumCore;
import dev.premium.core.gui.Gui;
import dev.premium.core.util.Fmt;
import dev.premium.core.util.ItemBuilder;
import dev.premium.core.util.Skin;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.entity.Player;

/** "Bestätigen": Zurück (Slot 2), Item (4), Bestätigen (6), Info (8) - mit Einzahlung, Erstellgebühr und Abholfrist. */
public final class OrderConfirmGui extends Gui {
    private final OrdersModule orders;
    private final Material material;
    private final int amount;
    private final double price;
    private final Gui back;

    public OrderConfirmGui(PremiumCore plugin, OrdersModule orders, Material material, int amount, double price, Gui back) {
        super(plugin, orders.title("confirm"), 1);
        this.orders = orders;
        this.material = material;
        this.amount = amount;
        this.price = price;
        this.back = back;
    }

    @Override
    protected Skin.Layout layout() {
        return Skin.Layout.BAR;
    }

    @Override
    protected void render(Player viewer) {
        double deposit = OrdersModule.round2(this.amount * this.price);
        double fee = this.orders.fee(deposit);
        double total = OrdersModule.round2(deposit + fee);
        String name = OrdersModule.itemTag(this.material);
        long days = this.plugin.getConfig().getLong("orders.pickup-days", 5L);

        this.set(2, Skin.btn("cancel", ItemBuilder.of(this.orders.button("cancel", Material.BARRIER)).name("<red><bold>Zurück").build()), e -> this.back.open(viewer));
        this.set(4, ItemBuilder.of(this.material).name("<white>" + name).amount(Math.max(1, Math.min(64, this.amount)))
                .lore("<gray>Anzahl: <aqua>" + Fmt.number((long) this.amount), "<gray>Preis pro Stück: <green>" + Fmt.money(this.price)).build());
        this.set(6, Skin.btn("confirm", ItemBuilder.of(this.orders.button("confirm", Material.LIME_DYE)).name("<green><bold>Bestätigen").lore("<gray>Gesamtzahlung: <green>" + Fmt.money(total)).glow().build()), e -> {
            this.orders.create(viewer, this.material, this.amount, this.price);
            viewer.closeInventory();
        });
        List<String> lore = new ArrayList<>();
        lore.add("<white>" + name);
        lore.add("<gray>Anzahl: <aqua>" + Fmt.number((long) this.amount));
        lore.add("<gray>Preis pro Stück: <green>" + Fmt.money(this.price));
        lore.add("");
        lore.add("<gray>Einzahlung: <green>" + Fmt.money(deposit));
        lore.add("<gray>Erstellgebühr: <red>" + Fmt.money(fee));
        lore.add("<gray>Gesamtzahlung: <green>" + Fmt.money(total));
        lore.add("");
        lore.add("<gray>Die Erstellgebühr wird beim");
        lore.add("<gray>Abbrechen nicht erstattet.");
        lore.add("");
        lore.add("<red>Jede Lieferung muss innerhalb von " + days + "d 0h abgeholt werden.");
        lore.add("<red>Nicht abgeholte Lieferungen verfallen endgültig.");
        this.set(8, Skin.btn("orders", ItemBuilder.of(this.orders.button("info", Material.ORANGE_DYE)).name("<white>" + name).lore(lore).build()));
    }
}
