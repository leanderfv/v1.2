package dev.premium.core.modules.orders;

import dev.premium.core.PremiumCore;
import dev.premium.core.gui.Gui;
import dev.premium.core.modules.orders.OrdersModule.Sort;
import dev.premium.core.modules.orders.OrdersModule.View;
import dev.premium.core.util.Fmt;
import dev.premium.core.util.ItemBuilder;
import dev.premium.core.util.Skin;
import dev.premium.core.util.Msg;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

/**
 * Order-Übersicht: oben 4x9 Orders, unten die Knopfleiste
 * (Aktualisieren, Suche, Vorherige Seite, Filter, Nächste Seite, Deine Orders, Order erstellen).
 */
public final class OrdersGui extends Gui {
    private static final int ITEMS = 36;
    private static final View[] MY_VIEWS = {View.ALL, View.OPEN, View.COMPLETED, View.EMPTIED, View.CANCELLED};

    private final OrdersModule orders;
    private View view = View.BROWSE;
    private Sort sort = Sort.NEWEST;
    private String search = "";
    private int page;

    public OrdersGui(PremiumCore plugin, OrdersModule orders) {
        super(plugin, orders.title("main"), 5);
        this.orders = orders;
    }

    @Override
    protected Skin.Layout layout() {
        return Skin.Layout.BAR;
    }

    @Override
    protected void render(Player viewer) {
        List<Order> list = this.orders.list(viewer.getUniqueId(), this.view, this.search, this.sort);
        int pages = Math.max(1, (list.size() + ITEMS - 1) / ITEMS);
        this.page = Math.max(0, Math.min(this.page, pages - 1));
        for (int i = 0; i < ITEMS; ++i) {
            int index = this.page * ITEMS + i;
            if (index >= list.size()) {
                break;
            }
            final Order order = list.get(index);
            this.set(i, this.orders.icon(order, viewer), e -> this.click(viewer, order, e));
        }
        if (list.isEmpty()) {
            this.set(13, ItemBuilder.of(Material.BARRIER).name("<red>Keine Orders gefunden")
                    .lore(this.view == View.BROWSE ? "<gray>Erstelle die erste Order mit dem grünen Plus." : "<gray>In dieser Ansicht gibt es nichts.").build());
        }
        this.buttons(viewer, pages);
    }

    private void buttons(Player viewer, int pages) {
        // Aktualisieren
        this.set(36, Skin.btn("refresh", ItemBuilder.of(this.orders.button("refresh", Material.RED_DYE)).name("<red><bold>Aktualisieren").build()), e -> this.refresh(viewer));
        // Suche
        List<String> searchLore = new ArrayList<>();
        if (!this.search.isEmpty()) {
            searchLore.add("<gray>Aktuell: <white>" + Msg.esc(this.search));
            searchLore.add("<dark_gray>Rechtsklick: Suche löschen");
        } else {
            searchLore.add("<gray>Nach einem Item suchen");
        }
        this.set(37, Skin.btn("search", ItemBuilder.of(this.orders.button("search", Material.SPYGLASS)).name("<red><bold>Suche").lore(searchLore).build()), e -> {
            if (e.isRightClick()) {
                this.search = "";
                this.page = 0;
                this.refresh(viewer);
                return;
            }
            this.orders.prompt(viewer, "Suche eingeben", "z. B. Elytra", t -> List.of("Suche: " + t), text -> {
                this.search = text.trim();
                this.page = 0;
                this.open(viewer);
            }, () -> this.open(viewer));
        });
        // Seiten
        this.set(39, Skin.btn("prev", ItemBuilder.of(this.orders.button("previous", Material.ARROW)).name("<aqua><bold>Vorherige Seite").lore("<gray>Seite " + (this.page + 1) + "/" + pages).build()), e -> {
            if (this.page > 0) {
                --this.page;
            }
            this.refresh(viewer);
        });
        this.set(41, Skin.btn("next", ItemBuilder.of(this.orders.button("next", Material.ARROW)).name("<aqua><bold>Nächste Seite").lore("<gray>Seite " + (this.page + 1) + "/" + pages).build()), e -> {
            if (this.page < pages - 1) {
                ++this.page;
            }
            this.refresh(viewer);
        });
        // Filter (Sortierung)
        List<String> filterLore = new ArrayList<>();
        for (Sort s : Sort.values()) {
            filterLore.add(s == this.sort ? "<aqua>> " + s.label : "<gray>" + s.label);
        }
        filterLore.add("");
        filterLore.add("<yellow>Klicken, um zu wechseln");
        this.set(40, Skin.btn("filter", ItemBuilder.of(this.orders.button("filter", Material.HOPPER)).name("<white><bold>Filter").lore(filterLore).build()), e -> {
            Sort[] all = Sort.values();
            this.sort = all[(this.sort.ordinal() + 1) % all.length];
            this.page = 0;
            this.refresh(viewer);
        });
        // Deine Orders
        List<String> myLore = new ArrayList<>();
        for (View v : MY_VIEWS) {
            myLore.add(v == this.view ? "<aqua>> " + v.label : "<gray>" + v.label);
        }
        myLore.add("");
        myLore.add("<gray>Insgesamt ausgegeben: <green>" + Fmt.money(this.orders.spent(viewer.getUniqueId())));
        myLore.add("<gray>Insgesamt verdient: <green>" + Fmt.money(this.orders.earned(viewer.getUniqueId())));
        myLore.add("");
        myLore.add("<yellow>Klicken, um zu wechseln");
        myLore.add("<dark_gray>(nach der letzten Ansicht zurück zu allen Orders)");
        this.set(43, Skin.btn("orders", ItemBuilder.of(this.orders.button("my-orders", Material.CHEST)).name("<gold><bold>Deine Orders").lore(myLore).build()), e -> {
            this.view = this.nextView();
            this.page = 0;
            this.refresh(viewer);
        });
        // Order erstellen
        this.set(44, Skin.btn("plus", ItemBuilder.of(this.orders.button("create", Material.EMERALD)).name("<green><bold>Order erstellen")
                .lore("<gray>Suche Items und biete", "<gray>einen Preis pro Stück an.").build()), e -> {
            ItemSelectGui select = new ItemSelectGui(this.plugin, this.orders, this);
            select.open(viewer);
        });
    }

    private View nextView() {
        if (this.view == View.BROWSE) {
            return MY_VIEWS[0];
        }
        for (int i = 0; i < MY_VIEWS.length; ++i) {
            if (MY_VIEWS[i] == this.view) {
                return i + 1 < MY_VIEWS.length ? MY_VIEWS[i + 1] : View.BROWSE;
            }
        }
        return View.BROWSE;
    }

    private void click(Player viewer, Order order, InventoryClickEvent e) {
        if (order.owner.equals(viewer.getUniqueId())) {
            if (e.isRightClick()) {
                this.orders.cancel(viewer, order);
            } else {
                this.orders.collect(viewer, order);
            }
        } else if (e.isLeftClick()) {
            this.orders.deliver(viewer, order);
        }
        this.refresh(viewer);
    }
}
