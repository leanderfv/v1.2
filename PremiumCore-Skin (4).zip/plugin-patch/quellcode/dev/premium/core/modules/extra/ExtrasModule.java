package dev.premium.core.modules.extra;

import dev.premium.core.PremiumCore;
import dev.premium.core.command.PlayerCommand;
import dev.premium.core.module.PluginModule;
import dev.premium.core.modules.home.HomeEntry;
import dev.premium.core.modules.home.HomeModule;
import dev.premium.core.util.Sfx;
import io.papermc.paper.chat.ChatRenderer;
import io.papermc.paper.event.player.AsyncChatEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import net.kyori.adventure.text.TextReplacementConfig;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.plugin.Plugin;

/**
 * Zusatz-Funktionen: Homes-Dashboard, Teleport-Cooldown, /tpa, /rtp, /settings, Combat, Chat-Filter,
 * /announce, /rules, /changelog, Bossbar und die Clan-Bank (/clan bank).
 * Alle Cooldowns und Werte stehen in der config.yml unter "extras", "combat", "rtp" und "announce".
 */
public final class ExtrasModule implements PluginModule, Listener {
    private PremiumCore plugin;
    private SettingsFeature settings;
    private CombatFeature combat;
    private TpaFeature tpa;
    private RtpFeature rtp;
    private PlayerPrefs prefs;
    private RulesFeature rules;
    private OnboardingFeature onboarding;
    private ClanStatsFeature clanStats;
    private ChangelogFeature changelog;
    private BossbarFeature bossbar;
    private AnnounceFeature announce;
    private ClanBankFeature clanBank;

    @Override
    public String id() {
        return "extras";
    }

    public RulesFeature rules() {
        return this.rules;
    }

    public PlayerPrefs prefs() {
        return this.prefs;
    }

    public ChangelogFeature changelog() {
        return this.changelog;
    }

    public BossbarFeature bossbar() {
        return this.bossbar;
    }

    public AnnounceFeature announce() {
        return this.announce;
    }

    @Override
    public void enable(PremiumCore plugin) {
        this.plugin = plugin;
        plugin.services().register(ExtrasModule.class, this);
        this.settings = new SettingsFeature(plugin, (p, s) -> {
            if (s == SettingsFeature.Setting.BOSSBAR && this.bossbar != null) {
                this.bossbar.refresh(p);
            }
        });
        this.combat = new CombatFeature(plugin);
        this.tpa = new TpaFeature(plugin, this.settings, this.combat);
        this.rtp = new RtpFeature(plugin, this.combat);
        this.prefs = new PlayerPrefs(plugin);
        dev.premium.core.i18n.Tr.bind(this.prefs);
        this.rules = new RulesFeature(plugin, this.prefs);
        this.changelog = new ChangelogFeature(plugin, this.prefs);
        this.bossbar = new BossbarFeature(plugin, this.settings);
        this.announce = new AnnounceFeature(plugin);
        this.clanBank = new ClanBankFeature(plugin);
        this.clanStats = new ClanStatsFeature(plugin, this.clanBank);
        this.onboarding = new OnboardingFeature(plugin, this.prefs, this.rules, this.changelog);
        for (Listener l : new Listener[]{this, this.combat, this.onboarding, this.bossbar, this.announce}) {
            Bukkit.getPluginManager().registerEvents(l, (Plugin) plugin);
        }
        PlayerCommand.bind(plugin, "tpa", null, (p, args) -> {
            if (args.length == 0) {
                this.tpa.openSelect(p);
                return;
            }
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                plugin.msg().err(p, "Spieler nicht gefunden.");
                return;
            }
            this.tpa.send(p, target);
        }, (p, args) -> args.length == 1 ? Bukkit.getOnlinePlayers().stream().map(Player::getName)
                .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(args[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList()) : List.<String>of());
        PlayerCommand.bind(plugin, "tpaccept", null, (p, args) -> this.tpa.accept(p));
        PlayerCommand.bind(plugin, "tpdeny", null, (p, args) -> this.tpa.deny(p));
        PlayerCommand.bind(plugin, "settings", null, (p, args) -> this.settings.open(p));
        PlayerCommand.bind(plugin, "rtp", null, (p, args) -> this.rtp.openMenu(p));
        PlayerCommand.bind(plugin, "announce", "premium.announce", (p, args) -> this.announce.start(p));
        PlayerCommand.bind(plugin, "rules", null, (p, args) -> {
            if (args.length > 0 && args[0].equalsIgnoreCase("reload") && p.hasPermission("premium.admin")) {
                this.rules.load();
                plugin.msg().ok(p, "rules.yml neu geladen.");
                return;
            }
            this.onboarding.openRules(p);
        });
        PlayerCommand.bind(plugin, "changelog", null, (p, args) -> {
            if (args.length > 0 && args[0].equalsIgnoreCase("reload") && p.hasPermission("premium.admin")) {
                this.changelog.load();
                plugin.msg().ok(p, "changelog.yml neu geladen.");
                return;
            }
            this.changelog.open(p);
        });
        PlayerCommand.bind(plugin, "homes", null, (p, args) -> this.openHomes(p));
        PlayerCommand.bind(plugin, "language", null, (p, args) -> this.onboarding.openLanguage(p));
    }

    @Override
    public void disable() {
        if (this.bossbar != null) {
            this.bossbar.shutdown();
        }
    }

    private void openHomes(Player p) {
        HomeModule homes = X.find(this.plugin, HomeModule.class);
        if (homes == null) {
            this.plugin.msg().err(p, "Das Home-System ist nicht aktiv.");
            return;
        }
        new HomeDashboardGui(this.plugin, homes, this.combat).open(p);
    }

    // ------------------------------------------------------------------ Befehle abfangen (Cooldowns, Combat, Home-GUI, Clan-Bank)

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        String raw = event.getMessage();
        if (raw.length() < 2) {
            return;
        }
        String[] parts = raw.substring(1).trim().split("\\s+");
        String cmd = parts[0].toLowerCase(Locale.ROOT);
        int colon = cmd.indexOf(':');
        if (colon >= 0) {
            cmd = cmd.substring(colon + 1);
        }
        String[] args = Arrays.copyOfRange(parts, 1, parts.length);
        Player p = event.getPlayer();
        if (this.onboarding.isBlocked(p)) {
            return;
        }
        List<String> blocked = this.plugin.getConfig().getStringList("combat.blocked-commands");
        if (blocked.isEmpty()) {
            blocked = List.of("spawn", "home", "homes", "tpa", "tpaccept", "rtp", "warp");
        }
        if (this.combat.inCombat(p) && blocked.contains(cmd)) {
            event.setCancelled(true);
            this.plugin.msg().err(p, "Das geht nicht im Kampf.");
            Sfx.ERROR.play(p);
            return;
        }
        switch (cmd) {
            case "homes" -> {
                event.setCancelled(true);
                this.openHomes(p);
            }
            case "home" -> {
                if (args.length == 0) {
                    event.setCancelled(true);
                    this.openHomes(p);
                    return;
                }
                if (!this.homeExists(p, args[0])) {
                    return;
                }
                if (!X.cooldownOk(this.plugin, p, "teleport")) {
                    event.setCancelled(true);
                    return;
                }
                X.cooldownSet(this.plugin, p, "teleport", 15);
            }
            case "spawn" -> {
                if (!X.cooldownOk(this.plugin, p, "teleport")) {
                    event.setCancelled(true);
                    return;
                }
                X.cooldownSet(this.plugin, p, "teleport", 15);
            }
            case "clan", "clans" -> {
                if (args.length == 0) {
                    // Clanstand zuerst; wer in keinem Clan ist, bekommt das normale /clan-Menü
                    if (this.clanStats.openHub(p)) {
                        event.setCancelled(true);
                    }
                    return;
                }
                switch (args[0].toLowerCase(Locale.ROOT)) {
                    case "bank" -> {
                        event.setCancelled(true);
                        this.clanBank.open(p);
                    }
                    case "bal", "balance", "kasse" -> {
                        event.setCancelled(true);
                        this.clanStats.showBalance(p);
                    }
                    case "baltop", "richest", "reichste" -> {
                        event.setCancelled(true);
                        this.clanStats.openBaltop(p, null);
                    }
                    default -> {
                    }
                }
            }
            default -> {
            }
        }
    }

    private boolean homeExists(Player p, String name) {
        HomeModule homes = X.find(this.plugin, HomeModule.class);
        if (homes == null) {
            return false;
        }
        List<HomeEntry> list = new ArrayList<HomeEntry>();
        for (Object o : homes.homesOf(p)) {
            if (o instanceof HomeEntry h) {
                list.add(h);
            }
        }
        return list.stream().anyMatch(h -> h.name().equalsIgnoreCase(name));
    }

    // ------------------------------------------------------------------ Chat: Chat aus + fette OP-Namen

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        Player sender = event.getPlayer();
        boolean op = sender.isOp();
        if (!op) {
            event.viewers().removeIf(a -> a instanceof Player v && !v.equals(sender) && !this.settings.get(v.getUniqueId(), SettingsFeature.Setting.CHAT));
        }
        if (op && this.plugin.getConfig().getBoolean("chat.op-bold-name", true)) {
            ChatRenderer previous = event.renderer();
            String name = sender.getName();
            event.renderer((source, displayName, message, viewer) -> previous.render(source, displayName, message, viewer)
                    .replaceText(TextReplacementConfig.builder().matchLiteral(name).once().replacement((r, b) -> b.decorate(TextDecoration.BOLD)).build()));
        }
    }

    // ------------------------------------------------------------------ Monster-Spawns nur dort, wo ein Spieler sie will

    @EventHandler(ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent event) {
        if (event.getSpawnReason() != CreatureSpawnEvent.SpawnReason.NATURAL || !(event.getEntity() instanceof Monster)) {
            return;
        }
        double radius = this.plugin.getConfig().getDouble("extras.mob-spawn-radius", 64.0);
        double r2 = radius * radius;
        boolean anyNearby = false;
        for (Player p : event.getLocation().getWorld().getPlayers()) {
            if (p.getLocation().distanceSquared(event.getLocation()) > r2) {
                continue;
            }
            anyNearby = true;
            if (this.settings.get(p.getUniqueId(), SettingsFeature.Setting.MOBS)) {
                return;
            }
        }
        if (anyNearby) {
            event.setCancelled(true);
        }
    }
}
