package dev.premium.core.modules.extra;

import dev.premium.core.PremiumCore;
import dev.premium.core.i18n.Tr;
import dev.premium.core.gui.Gui;
import dev.premium.core.gui.PagedGui;
import dev.premium.core.util.ItemBuilder;
import dev.premium.core.util.Skin;
import dev.premium.core.util.Msg;
import dev.premium.core.util.Sfx;
import dev.premium.core.util.Ui;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

/** /tpa: Spielerauswahl (Köpfe) -> Bestätigung (grünes Glas = senden, rotes Glas = abbrechen). */
final class TpaFeature {
    private record Request(UUID from, long expires) {
    }

    private final PremiumCore plugin;
    private final SettingsFeature settings;
    private final CombatFeature combat;
    private final Map<UUID, Request> pending = new ConcurrentHashMap<UUID, Request>();

    TpaFeature(PremiumCore plugin, SettingsFeature settings, CombatFeature combat) {
        this.plugin = plugin;
        this.settings = settings;
        this.combat = combat;
    }

    void openSelect(Player p) {
        new SelectGui(p).open(p);
    }

    void send(Player from, Player to) {
        if (from.equals(to)) {
            this.plugin.msg().err(from, "Du kannst dir selbst keine Anfrage schicken.");
            return;
        }
        if (!to.isOnline()) {
            this.plugin.msg().err(from, "Dieser Spieler ist nicht mehr online.");
            return;
        }
        if (this.combat.inCombat(from)) {
            this.plugin.msg().err(from, "Du kannst dich im Kampf nicht teleportieren.");
            return;
        }
        if (!this.settings.get(to.getUniqueId(), SettingsFeature.Setting.TPA) && !from.isOp()) {
            this.plugin.msg().err(from, "<yellow>" + Msg.esc(to.getName()) + "<red> hat TPA-Anfragen deaktiviert.");
            Sfx.ERROR.play(from);
            return;
        }
        if (!X.cooldownOk(this.plugin, from, "tpa")) {
            return;
        }
        X.cooldownSet(this.plugin, from, "tpa", 5);
        this.pending.put(to.getUniqueId(), new Request(from.getUniqueId(), System.currentTimeMillis() + 60000L));
        this.plugin.msg().ok(from, "TPA-Anfrage an <yellow>" + Msg.esc(to.getName()) + "<green> gesendet (60 Sekunden gültig).");
        to.sendMessage(this.plugin.msg().prefixed(to, "<yellow>" + Msg.esc(from.getName()) + "<gray> möchte sich zu dir teleportieren. "
                + "<click:run_command:/tpaccept><green><bold>[Annehmen]</bold></click> <click:run_command:/tpdeny><red><bold>[Ablehnen]</bold></click>"));
        Sfx.CHIME.play(to);
    }

    void accept(Player target) {
        Request r = this.pending.remove(target.getUniqueId());
        if (r == null || r.expires() < System.currentTimeMillis()) {
            this.plugin.msg().err(target, "Du hast keine offene TPA-Anfrage.");
            return;
        }
        Player from = Bukkit.getPlayer(r.from());
        if (from == null) {
            this.plugin.msg().err(target, "Der Spieler ist nicht mehr online.");
            return;
        }
        if (this.combat.inCombat(from)) {
            this.plugin.msg().err(target, "<yellow>" + Msg.esc(from.getName()) + "<red> ist gerade im Kampf.");
            return;
        }
        this.plugin.msg().ok(target, "Du hast die Anfrage von <yellow>" + Msg.esc(from.getName()) + "<green> angenommen.");
        this.plugin.msg().info(from, "<yellow>" + Msg.esc(target.getName()) + "<gray> hat deine Anfrage angenommen.");
        this.plugin.teleports().teleport(from, target.getLocation(), target.getName());
    }

    void deny(Player target) {
        Request r = this.pending.remove(target.getUniqueId());
        if (r == null || r.expires() < System.currentTimeMillis()) {
            this.plugin.msg().err(target, "Du hast keine offene TPA-Anfrage.");
            return;
        }
        this.plugin.msg().info(target, "Anfrage abgelehnt.");
        Player from = Bukkit.getPlayer(r.from());
        if (from != null) {
            this.plugin.msg().err(from, "<yellow>" + Msg.esc(target.getName()) + "<red> hat deine Anfrage abgelehnt.");
        }
    }

    private final class SelectGui extends PagedGui<Player> {
        SelectGui(Player requester) {
            super(TpaFeature.this.plugin, Ui.title("TPA - Spieler wählen", "#55FFFF", "#5555FF"), null,
                    () -> Bukkit.getOnlinePlayers().stream().filter(x -> !x.equals(requester)).collect(Collectors.<Player>toList()));
        }

        @Override
        protected ItemStack icon(Player entry) {
            return ItemBuilder.of(Material.PLAYER_HEAD).skull(entry).name("<yellow><bold>" + Msg.esc(entry.getName()))
                    .lore("<gray>Klicke, um eine TPA-Anfrage vorzubereiten").build();
        }

        @Override
        protected void select(Player viewer, Player entry, InventoryClickEvent event) {
            new ConfirmGui(viewer, entry).open(viewer);
        }

        @Override
        protected String emptyText() {
            return "<red>Kein anderer Spieler online";
        }
    }

    private final class ConfirmGui extends Gui {
        private final Player target;

        ConfirmGui(Player requester, Player target) {
            super(TpaFeature.this.plugin, Ui.title("TPA an " + target.getName(), "#55FFFF", "#5555FF"), 3);
            this.target = target;
        }

        @Override
        protected void render(Player viewer) {
            this.border(Material.BLACK_STAINED_GLASS_PANE);
            this.set(13, ItemBuilder.of(Material.PLAYER_HEAD).skull(this.target).name("<yellow><bold>" + Msg.esc(this.target.getName()))
                    .lore("<gray>Zu diesem Spieler teleportieren").build());
            this.set(11, Skin.btn("cancel", ItemBuilder.of(Material.RED_STAINED_GLASS_PANE).name("<red><bold>Abbrechen").lore("<gray>Zurück zur Spielerliste").build()),
                    e -> TpaFeature.this.openSelect(viewer));
            this.set(15, Skin.btn("confirm", ItemBuilder.of(Material.LIME_STAINED_GLASS_PANE).name("<green><bold>TPA senden").lore("<gray>Anfrage an den Spieler schicken").build()), e -> {
                viewer.closeInventory();
                TpaFeature.this.send(viewer, this.target);
            });
        }
    }
}
