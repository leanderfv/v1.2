package dev.premium.core.modules.extra;

import dev.premium.core.PremiumCore;
import dev.premium.core.gui.Gui;
import dev.premium.core.util.ItemBuilder;
import dev.premium.core.util.Msg;
import dev.premium.core.util.Sfx;
import dev.premium.core.util.Skin;
import io.papermc.paper.event.player.AsyncChatEvent;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

/**
 * Ablauf beim allerersten Join: 1) Sprache wählen (DE/EN), 2) Regeln Seite für Seite lesen und auf der letzten Seite
 * akzeptieren. Währenddessen sind ESC (das Fenster öffnet sich sofort wieder), Bewegen, Chat, Befehle, Schaden und
 * Interaktionen gesperrt. Zusätzlich zeigt das Plugin jedem Spieler beim nächsten Join neue Changelog-Einträge.
 * Der Zustand steht in playerstate.yml - bricht ein neuer Spieler ab, geht es beim nächsten Join an derselben Stelle weiter.
 */
public final class OnboardingFeature implements Listener {
    private final PremiumCore plugin;
    private final PlayerPrefs prefs;
    private final RulesFeature rules;
    private final ChangelogFeature changelog;
    private final Set<UUID> blocked = ConcurrentHashMap.newKeySet();
    /** Das aktuell offene Pflicht-Fenster pro Spieler (bleibt beim Wiederöffnen erhalten, z. B. die Regel-Seite). */
    private final Map<UUID, Gui> active = new ConcurrentHashMap<UUID, Gui>();
    /** Wächter: öffnet das Fenster wieder, wenn es aus irgendeinem Grund zu ist (Client schließt es beim Laden, anderes Plugin, ESC). */
    private final Map<UUID, BukkitTask> watchdogs = new ConcurrentHashMap<UUID, BukkitTask>();
    /** Zeitpunkt (ms), zu dem das Pflicht-Fenster zuletzt geoeffnet wurde - erkennt Fenster, die sofort wieder zugehen. */
    private final Map<UUID, Long> openedAt = new ConcurrentHashMap<UUID, Long>();
    /** Wie oft das Fenster hintereinander sofort (< 1 s) wieder zuging - steuert die Wartezeit vor dem naechsten Oeffnen. */
    private final Map<UUID, Integer> quickCloses = new ConcurrentHashMap<UUID, Integer>();
    /** Spieler, bei denen schon ein verzoegertes Wiederoeffnen geplant ist (verhindert doppeltes Oeffnen). */
    private final Set<UUID> pending = ConcurrentHashMap.newKeySet();

    OnboardingFeature(PremiumCore plugin, PlayerPrefs prefs, RulesFeature rules, ChangelogFeature changelog) {
        this.plugin = plugin;
        this.prefs = prefs;
        this.rules = rules;
        this.changelog = changelog;
    }

    private boolean enabled() {
        return this.plugin.getConfig().getBoolean("onboarding.enabled", true);
    }

    boolean isBlocked(Player p) {
        return this.blocked.contains(p.getUniqueId());
    }

    /** /rules: Regelwerk als Menü (nur lesen). */
    void openRules(Player p) {
        new RulesGui(this.prefs.lang(p), true).open(p);
    }

    /** /language: Sprache jederzeit ändern. */
    void openLanguage(Player p) {
        new LanguageGui(false).open(p);
    }

    private String hint(Player p) {
        if (!this.prefs.hasLang(p.getUniqueId())) {
            return "Select your language first. / Wähle zuerst deine Sprache.";
        }
        return this.prefs.t(p, "Lies die Regeln bis zur letzten Seite und akzeptiere sie.", "Read the rules to the last page and accept them.");
    }

    // ------------------------------------------------------------------ Join

    /** Sprache des Spielers früh merken, damit schon die ersten Nachrichten/Fenster nach dem Join in seiner Sprache kommen. */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onJoinLang(PlayerJoinEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        dev.premium.core.i18n.Tr.mark(id, this.prefs.lang(id));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();
        UUID id = p.getUniqueId();
        if (this.enabled() && !p.hasPlayedBefore() && !this.prefs.rulesAccepted(id)) {
            this.prefs.setOnboardingPending(id, true);
        }
        if (this.enabled() && this.prefs.onboardingPending(id)) {
            this.blocked.add(id);
            this.startWatchdog(p);
            return;
        }
        Bukkit.getScheduler().runTaskLater((Plugin) this.plugin, () -> {
            if (p.isOnline() && !this.blocked.contains(id)) {
                this.changelog.openUnseen(p);
            }
        }, 60L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        this.blocked.remove(id);
        this.active.remove(id);
        this.openedAt.remove(id);
        this.quickCloses.remove(id);
        this.pending.remove(id);
        this.stopWatchdog(id);
    }

    /**
     * Prüft alle 10 Ticks, ob der gesperrte Spieler sein Pflicht-Fenster offen hat, und öffnet es sonst (wieder).
     * Nötig, weil der Client ein Fenster, das direkt nach dem Join geöffnet wird, beim Fertigladen der Welt wieder
     * schließen kann - ohne den Wächter bliebe der Spieler dann gesperrt, aber ohne Fenster.
     */
    private void startWatchdog(Player p) {
        UUID id = p.getUniqueId();
        this.stopWatchdog(id);
        BukkitTask task = Bukkit.getScheduler().runTaskTimer((Plugin) this.plugin, () -> {
            if (!p.isOnline() || !this.blocked.contains(id)) {
                this.stopWatchdog(id);
                return;
            }
            if (this.pending.contains(id)) {
                return;
            }
            InventoryHolder top = p.getOpenInventory().getTopInventory().getHolder(false);
            if (!(top instanceof LanguageGui) && !(top instanceof RulesGui)) {
                this.next(p);
            }
        }, 20L, 10L);
        this.watchdogs.put(id, task);
    }

    private void stopWatchdog(UUID id) {
        BukkitTask task = this.watchdogs.remove(id);
        if (task != null) {
            task.cancel();
        }
    }

    /** Öffnet den nächsten offenen Schritt (Sprache, dann Regeln) oder schließt das Onboarding ab. */
    private void next(Player p) {
        UUID id = p.getUniqueId();
        if (!p.isOnline() || !this.blocked.contains(id)) {
            return;
        }
        Gui current = this.active.get(id);
        if (!this.prefs.hasLang(id)) {
            LanguageGui gui = current instanceof LanguageGui lg ? lg : new LanguageGui(true);
            this.active.put(id, gui);
            this.open(gui, p);
            return;
        }
        if (this.rules.required() && !this.prefs.rulesAccepted(id)) {
            Lang lang = this.prefs.lang(id);
            RulesGui gui = current instanceof RulesGui rg && rg.lang == lang ? rg : new RulesGui(lang);
            this.active.put(id, gui);
            this.open(gui, p);
            return;
        }
        this.finish(p);
    }

    private void finish(Player p) {
        UUID id = p.getUniqueId();
        this.blocked.remove(id);
        this.stopWatchdog(id);
        Gui shown = this.active.remove(id);
        if (shown != null && p.getOpenInventory().getTopInventory() == shown.getInventory()) {
            p.closeInventory();
        }
        this.prefs.setOnboardingPending(id, false);
        this.prefs.setChangelogSeen(id, this.changelog.latestCreated());
        p.showTitle(Title.title(Msg.mm(this.prefs.t(p, "<green><bold>Willkommen!", "<green><bold>Welcome!")),
                Msg.mm(this.prefs.t(p, "<gray>Viel Spaß auf dem Server", "<gray>Have fun on the server")),
                Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(3), Duration.ofMillis(600))));
        Sfx.SUCCESS.play(p);
        if (!this.rules.required() && this.rules.showOnFirstJoin()) {
            this.openRules(p);
        }
    }

    // ------------------------------------------------------------------ Sperren, solange das Onboarding offen ist

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (!this.isBlocked(event.getPlayer())) {
            return;
        }
        Location from = event.getFrom();
        Location to = event.getTo();
        if (to != null && (from.getX() != to.getX() || from.getY() != to.getY() || from.getZ() != to.getZ())) {
            // WICHTIG: NICHT event.setTo(from)! setTo() loest intern einen Teleport aus, und ein Teleport schliesst jedes
            // offene Fenster (das war der Grund, warum sich Sprach-/Regelfenster nach ca. 0,5 s von selbst schlossen).
            // Abbrechen setzt den Spieler zurueck, ohne das Fenster zu schliessen.
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (this.isBlocked(event.getPlayer())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(Msg.mm("<red>" + Msg.esc(this.hint(event.getPlayer()))));
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent event) {
        if (this.isBlocked(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player p && this.isBlocked(p)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onInteract(PlayerInteractEvent event) {
        if (this.isBlocked(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onBreak(BlockBreakEvent event) {
        if (this.isBlocked(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onPlace(BlockPlaceEvent event) {
        if (this.isBlocked(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onDrop(PlayerDropItemEvent event) {
        if (this.isBlocked(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onPickup(EntityPickupItemEvent event) {
        if (event.getEntity() instanceof Player p && this.isBlocked(p)) {
            event.setCancelled(true);
        }
    }

    // ------------------------------------------------------------------ gemeinsame Hilfen

    /** Oeffnet das Fenster und merkt sich den Zeitpunkt (um sofortiges Wieder-Schliessen zu erkennen). */
    private void open(Gui gui, Player p) {
        this.openedAt.put(p.getUniqueId(), System.currentTimeMillis());
        gui.open(p);
    }

    /**
     * Oeffnet ein gesperrtes Fenster nach dem Schliessen (ESC, Client, anderes Plugin) wieder.
     * Geht es sofort (< 1 s nach dem Oeffnen) wieder zu, wird die Wartezeit schrittweise laenger (max. 2 s),
     * damit es nicht im Sekundentakt auf- und zuflackert.
     */
    private void reopen(Gui gui, Player p) {
        UUID id = p.getUniqueId();
        Long opened = this.openedAt.get(id);
        int quick = 0;
        if (opened != null && System.currentTimeMillis() - opened < 1000L) {
            quick = this.quickCloses.merge(id, 1, Integer::sum);
        } else {
            this.quickCloses.remove(id);
        }
        long delay = quick == 0 ? 2L : Math.min(40L, 5L * (quick + 1));
        if (!this.pending.add(id)) {
            return;
        }
        Bukkit.getScheduler().runTaskLater((Plugin) this.plugin, () -> {
            this.pending.remove(id);
            if (p.isOnline() && this.blocked.contains(id) && p.getOpenInventory().getTopInventory() != gui.getInventory()) {
                this.open(gui, p);
            }
        }, delay);
    }

    private static String plain(String legacy) {
        return legacy.replaceAll("(?i)&#[0-9a-f]{6}", "").replaceAll("(?i)[&§][0-9a-fk-or]", "");
    }

    // ------------------------------------------------------------------ Schritt 1: Sprache

    private final class LanguageGui extends Gui {
        private final boolean forced;
        private boolean done;

        LanguageGui(boolean forced) {
            super(OnboardingFeature.this.plugin, Skin.enabled() ? "<gold><bold>Language / Sprache" : "<gold><bold>Select your language to continue", 3);
            this.forced = forced;
        }

        @Override
        protected boolean translated() {
            return false;
        }

        @Override
        protected void render(Player viewer) {
            Lang current = OnboardingFeature.this.prefs.hasLang(viewer.getUniqueId()) ? OnboardingFeature.this.prefs.lang(viewer) : null;
            this.border(Material.BLACK_STAINED_GLASS_PANE);
            ItemBuilder de = ItemBuilder.of(Material.RED_BANNER).name("<yellow><bold>Deutsch").lore("<gray>Klicke, um Deutsch zu wählen", "", "<yellow>▶ Klicken");
            ItemBuilder en = ItemBuilder.of(Material.BLUE_BANNER).name("<yellow><bold>English").lore("<gray>Click to choose English", "", "<yellow>▶ Click");
            if (current == Lang.DE) {
                de.glow();
            }
            if (current == Lang.EN) {
                en.glow();
            }
            this.set(11, Skin.icon("flag/de", de.build()), e -> this.choose(viewer, Lang.DE));
            this.set(15, Skin.icon("flag/en", en.build()), e -> this.choose(viewer, Lang.EN));
            this.set(13, Skin.icon("flag/globe", ItemBuilder.of(Material.COMPASS).name("<gold><bold>Language / Sprache")
                    .lore("<gray>Select your language to continue", "<gray>Wähle deine Sprache, um fortzufahren").build()));
            if (!this.forced) {
                this.closeButton(22);
            }
        }

        private void choose(Player viewer, Lang lang) {
            OnboardingFeature.this.prefs.setLang(viewer.getUniqueId(), lang);
            this.done = true;
            Sfx.SUCCESS.play(viewer);
            if (this.forced) {
                Bukkit.getScheduler().runTask((Plugin) OnboardingFeature.this.plugin, () -> OnboardingFeature.this.next(viewer));
            } else {
                viewer.closeInventory();
                viewer.sendMessage(Msg.mm(lang == Lang.EN ? "<green>Language set to <white>English<green>." : "<green>Sprache auf <white>Deutsch<green> gestellt."));
            }
        }

        @Override
        public void onClose(Player player) {
            if (this.forced && !this.done) {
                OnboardingFeature.this.reopen(this, player);
            }
        }
    }

    // ------------------------------------------------------------------ Schritt 2: Regeln lesen und akzeptieren

    private final class RulesGui extends Gui {
        private static final int TEXT_SLOTS = 7;
        private final Lang lang;
        private final List<String> pages;
        private int page;
        private boolean done;
        private final boolean viewOnly;

        RulesGui(Lang lang) {
            this(lang, false);
        }

        /** viewOnly = /rules: nur lesen, ohne Akzeptieren/Ablehnen und ohne Zwangs-Wiederöffnen. */
        RulesGui(Lang lang, boolean viewOnly) {
            super(OnboardingFeature.this.plugin, Skin.enabled() ? (lang == Lang.EN ? "<gold><bold>RULES" : "<gold><bold>REGELWERK")
                    : (lang == Lang.EN ? "<gold><bold>Rules - read to the last page" : "<gold><bold>Regeln - bis zur letzten Seite lesen"), 5);
            this.lang = lang;
            this.viewOnly = viewOnly;
            this.pages = OnboardingFeature.this.rules.pages(lang);
        }

        private String t(String de, String en) {
            return this.lang == Lang.EN ? en : de;
        }

        @Override
        protected boolean translated() {
            return false;
        }

        @Override
        protected Skin.Layout layout() {
            return Skin.Layout.SCROLL;
        }

        /** Icon aus dem Pack: Buch für Überschriften, Zettel mit Nummer, wenn die Zeile mit "1." o. ä. beginnt. */
        private String ruleIcon(boolean heading, String line) {
            if (heading) {
                return "rules/book";
            }
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("^\\D{0,2}?(\\d{1,2})[.):]").matcher(line);
            if (m.find()) {
                int n = Integer.parseInt(m.group(1));
                if (n >= 1 && n <= 9) {
                    return "rules/n" + n;
                }
            }
            return "rules/scroll";
        }

        @Override
        protected void render(Player viewer) {
            int last = this.pages.size() - 1;
            this.page = Math.max(0, Math.min(this.page, last));
            this.border(Material.BLACK_STAINED_GLASS_PANE);
            this.set(4, Skin.icon("rules/book", ItemBuilder.of(Material.WRITTEN_BOOK).name(this.t("<gold><bold>Regelwerk", "<gold><bold>Rules"))
                    .lore(this.t("<gray>Lies bis zur letzten Seite.", "<gray>Read to the last page."), "", this.t("<gray>Fahre mit der Maus über die Zettel,", "<gray>Hover over the papers to read"), this.t("<gray>um den Text zu lesen.", "<gray>the text.")).glow().build()));
            List<String> lines = new ArrayList<String>();
            for (String line : plain(this.pages.get(this.page)).split("\n")) {
                if (!line.isBlank()) {
                    lines.add(line.trim());
                }
            }
            if (lines.size() > TEXT_SLOTS) {
                String merged = String.join(" ", lines.subList(TEXT_SLOTS - 1, lines.size()));
                lines = new ArrayList<String>(lines.subList(0, TEXT_SLOTS - 1));
                lines.add(merged);
            }
            for (int i = 0; i < lines.size(); i++) {
                List<String> wrapped = X.wrap(Msg.esc(lines.get(i)), 38);
                List<String> lore = new ArrayList<String>();
                for (int w = 1; w < wrapped.size(); w++) {
                    lore.add("<gray>" + wrapped.get(w));
                }
                boolean heading = i == 0 && this.pages.get(this.page).trim().startsWith("&6");
                this.set(10 + i, Skin.icon(this.ruleIcon(heading, lines.get(i)), ItemBuilder.of(heading ? Material.BOOK : Material.PAPER)
                        .name((heading ? "<gold><bold>" : "<white>") + wrapped.get(0)).lore(lore).build()));
            }
            if (this.page > 0) {
                this.set(29, Skin.btn("prev", ItemBuilder.of(Material.SPECTRAL_ARROW).name(this.t("<green>« Zurück", "<green>« Back")).build()), e -> {
                    --this.page;
                    this.refresh(viewer);
                });
            }
            if (this.page < last) {
                this.set(33, Skin.btn("next", ItemBuilder.of(Material.SPECTRAL_ARROW).name(this.t("<green>Weiter »", "<green>Next »")).build()), e -> {
                    ++this.page;
                    this.refresh(viewer);
                });
            }
            this.set(31, Skin.icon("rules/scroll", ItemBuilder.of(Material.PAPER).name(this.t("<white>Seite <yellow>", "<white>Page <yellow>") + (this.page + 1) + "<gray>/<yellow>" + (last + 1))
                    .lore(this.page == last ? this.t("<green>Du bist auf der letzten Seite.", "<green>You are on the last page.")
                            : this.t("<gray>Lies bis zur letzten Seite.", "<gray>Read to the last page.")).build()));
            if (this.viewOnly) {
                this.set(22, Skin.icon("rules/accept", ItemBuilder.of(Material.LIME_CONCRETE).name(this.t("<green><bold>✔ Verstanden", "<green><bold>✔ Got it"))
                        .lore("<yellow>▶ " + this.t("Klicken zum Schließen", "Click to close")).build()), e -> viewer.closeInventory());
            } else if (this.page == last) {
                this.set(22, Skin.icon("rules/accept", ItemBuilder.of(Material.LIME_CONCRETE).name(this.t("<green><bold>✔ Ich akzeptiere die Regeln", "<green><bold>✔ I accept the rules"))
                        .lore(this.t("<gray>Klicke, um die Regeln zu akzeptieren", "<gray>Click to accept the rules"), "", "<yellow>▶ " + this.t("Klicken", "Click")).glow().build()), e -> this.accept(viewer));
            } else {
                this.set(22, Skin.icon("rules/lock", ItemBuilder.of(Material.GRAY_STAINED_GLASS_PANE).name(this.t("<dark_gray>🔒 Akzeptieren", "<dark_gray>🔒 Accept"))
                        .lore(this.t("<gray>Erst auf der letzten Seite möglich.", "<gray>Only possible on the last page.")).build()));
            }
            if (this.viewOnly) {
                this.set(40, Skin.icon("rules/decline", ItemBuilder.of(Material.BARRIER).name(this.t("<red><bold>Schließen", "<red><bold>Close")).build()), e -> viewer.closeInventory());
            } else if (OnboardingFeature.this.plugin.getConfig().getBoolean("onboarding.allow-decline", true)) {
                this.set(40, Skin.icon("rules/decline", ItemBuilder.of(Material.RED_CONCRETE).name(this.t("<red><bold>✘ Ablehnen und verlassen", "<red><bold>✘ Decline and leave"))
                        .lore(this.t("<gray>Du wirst vom Server getrennt.", "<gray>You will be disconnected.")).build()), e -> {
                    this.done = true;
                    viewer.kick(Msg.mm(this.t("<red>Du musst die Regeln akzeptieren, um zu spielen.", "<red>You have to accept the rules to play.")));
                });
            }
        }

        private void accept(Player viewer) {
            OnboardingFeature.this.prefs.setRulesAccepted(viewer.getUniqueId(), true);
            this.done = true;
            Bukkit.getScheduler().runTask((Plugin) OnboardingFeature.this.plugin, () -> {
                viewer.closeInventory();
                OnboardingFeature.this.next(viewer);
            });
        }

        @Override
        public void onClose(Player player) {
            if (!this.done && !this.viewOnly) {
                OnboardingFeature.this.reopen(this, player);
            }
        }
    }
}
