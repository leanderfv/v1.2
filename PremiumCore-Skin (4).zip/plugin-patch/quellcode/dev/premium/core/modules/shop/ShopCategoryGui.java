package dev.premium.core.modules.shop;

import dev.premium.core.PremiumCore;
import dev.premium.core.i18n.Tr;
import dev.premium.core.gui.Gui;
import dev.premium.core.service.ShopCategory;
import dev.premium.core.util.Fmt;
import dev.premium.core.util.ItemBuilder;
import dev.premium.core.util.ItemValue;
import dev.premium.core.util.Msg;
import dev.premium.core.util.Skin;
import dev.premium.core.util.Sfx;
import dev.premium.core.util.Ui;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.ComponentLike;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

public final class ShopCategoryGui extends Gui {
    private static final int[] SLOTS = {10, 11, 12, 13, 14, 15, 16};
    private final ShopCategory category;
    private final Gui parent;
    private int page;

    public ShopCategoryGui(PremiumCore plugin, ShopCategory category, Gui parent) {
        super(plugin, category.color() + "<bold>" + Msg.esc(category.display()), 3);
        this.category = category;
        this.parent = parent;
    }

    private ItemStack icon(Material m) {
        return ItemBuilder.of(m).lore(
                "<gray>Kaufen: <green>" + Fmt.money(this.plugin.prices().buyPrice(m)) + " <dark_gray>pro St\u00fcck",
                "<gray>Verkaufen: <gold>" + Fmt.money(this.plugin.prices().sellPrice(m)) + " <dark_gray>pro St\u00fcck",
                "",
                "<green>Links: <white>Kaufen <dark_gray>\u00b7 <green>Shift+Links: <white>Stack",
                "<red>Rechts: <white>1 verkaufen <dark_gray>\u00b7 <red>Shift+Rechts: <white>alle").build();
    }

    @Override
    protected void render(Player viewer) {
        List<Material> entries = this.plugin.prices().shopItems(this.category);
        int pages = Math.max(1, (int) Math.ceil(entries.size() / (double) SLOTS.length));
        this.page = Math.min(this.page, pages - 1);
        int from = this.page * SLOTS.length;
        int count = Math.max(0, Math.min(SLOTS.length, entries.size() - from));
        // mittig anordnen
        int offset = (SLOTS.length - count) / 2;
        for (int i = 0; i < count; ++i) {
            final Material m = entries.get(from + i);
            this.set(SLOTS[offset + i], this.icon(m), e -> {
                if (e.isLeftClick()) {
                    new BuyGui(this.plugin, m, this, e.isShiftClick() ? m.getMaxStackSize() : 1).open(viewer);
                } else if (e.isRightClick()) {
                    this.sell(viewer, m, e.isShiftClick());
                    this.refresh(viewer);
                }
            });
        }
        if (this.page > 0) {
            this.set(20, Skin.btn("prev", ItemBuilder.of(Material.SPECTRAL_ARROW).name("<green>\u00ab Vorherige Seite").build()), e -> {
                --this.page;
                this.refresh(viewer);
            });
        }
        if (this.page < pages - 1) {
            this.set(24, Skin.btn("next", ItemBuilder.of(Material.SPECTRAL_ARROW).name("<green>N\u00e4chste Seite \u00bb").build()), e -> {
                ++this.page;
                this.refresh(viewer);
            });
        }
        if (this.parent != null) {
            this.backButton(18, this.parent);
        }
    }

    private void sell(Player player, Material m, boolean all) {
        PlayerInventory inv = player.getInventory();
        ItemStack plain = new ItemStack(m);
        int have = 0;
        for (ItemStack s : inv.getStorageContents()) {
            if (s == null || !ItemValue.strip(s).isSimilar(plain)) continue;
            have += s.getAmount();
        }
        int amount = all ? have : Math.min(1, have);
        if (amount <= 0) {
            this.plugin.msg().err((CommandSender) player, "Du hast dieses Item nicht (unveredelt) dabei.", new TagResolver[0]);
            Sfx.ERROR.play(player);
            return;
        }
        int remaining = amount;
        ItemStack[] contents = inv.getStorageContents();
        for (int i = 0; i < contents.length && remaining > 0; ++i) {
            ItemStack s = contents[i];
            if (s == null || !ItemValue.strip(s).isSimilar(plain)) continue;
            int take = Math.min(remaining, s.getAmount());
            remaining -= take;
            if (take == s.getAmount()) {
                inv.setItem(i, null);
                continue;
            }
            s.setAmount(s.getAmount() - take);
            inv.setItem(i, s);
        }
        double gain = this.plugin.prices().sellPrice(m) * (double) amount;
        this.plugin.economy().deposit((OfflinePlayer) player, gain);
        player.sendActionBar(this.plugin.msg().prefixed(player, "<gold>Verkauft: <white><n>x <item> <dark_gray>· <green>+<gain>", new TagResolver[]{Placeholder.unparsed("n", String.valueOf(amount)), Placeholder.component("item", (ComponentLike) Component.translatable(m.translationKey())), Placeholder.unparsed("gain", Fmt.money(gain))}));
        this.plugin.logs().log(dev.premium.core.service.LogService.PLAYER, "SELL", player.getUniqueId().toString(), player.getName(), null, null, gain, amount, "Shop", m.name());
        Sfx.SUCCESS.play(player, 1.6f);
    }

}
