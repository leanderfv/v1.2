package dev.premium.core.modules.shop;

import dev.premium.core.PremiumCore;
import dev.premium.core.i18n.Tr;
import dev.premium.core.gui.Gui;
import dev.premium.core.service.LogService;
import dev.premium.core.util.Fmt;
import dev.premium.core.util.ItemBuilder;
import dev.premium.core.util.Skin;
import dev.premium.core.util.ItemValue;
import dev.premium.core.util.Msg;
import dev.premium.core.util.Sfx;
import dev.premium.core.util.TextUtil;
import java.util.HashMap;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.ComponentLike;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/**
 * Kauf-Bestätigung (3 Reihen): Item in der Mitte, links -64/-10/-1, rechts +1/+10/+64,
 * unten Abbrechen (rot), Kaufen (grün) und "Inventar füllen" (Trichter). Preise gelten immer für die gewählte Menge.
 */
public final class BuyGui extends Gui {
    private final Material material;
    private final Gui parent;
    private int amount;

    public BuyGui(PremiumCore plugin, Material material, Gui parent, int amount) {
        super(plugin, "<dark_gray>Kaufen", 3);
        this.material = material;
        this.parent = parent;
        this.amount = Math.max(1, amount);
    }

    /** Freier Platz für dieses Item im Inventar (in Stück). */
    static int capacity(Player player, Material m) {
        ItemStack plain = new ItemStack(m);
        int max = m.getMaxStackSize();
        int room = 0;
        for (ItemStack s : player.getInventory().getStorageContents()) {
            if (s == null || s.getType().isAir()) {
                room += max;
            } else if (s.getAmount() < max && ItemValue.strip(s).isSimilar(plain)) {
                room += max - s.getAmount();
            }
        }
        return room;
    }

    /** Größte wählbare Menge: ein komplettes Inventar voll (unabhängig davon, wie voll es gerade ist). */
    private int maxAmount() {
        return Math.max(1, this.material.getMaxStackSize() * 36);
    }

    private void change(Player viewer, int delta) {
        this.amount = Math.max(1, Math.min(this.maxAmount(), this.amount + delta));
        this.refresh(viewer);
    }

    private ItemStack adjust(boolean plus, int n, Player viewer) {
        String sign = plus ? "+" : "-";
        double unit = this.plugin.prices().buyPrice(this.material);
        int target = Math.max(1, Math.min(this.maxAmount(), plus ? this.amount + n : this.amount - n));
        return Skin.btn(plus ? "plus" : "minus", ItemBuilder.of(plus ? Material.LIME_STAINED_GLASS_PANE : Material.RED_STAINED_GLASS_PANE)
                .amount(n)
                .name((plus ? "<green><bold>" : "<red><bold>") + sign + n)
                .lore("<gray>Menge: <white>" + this.amount + " <dark_gray>\u2192 <white>" + target,
                        "<gray>Preis: <green>" + Fmt.money(unit * target)).build());
    }

    @Override
    protected void render(Player viewer) {
        Material m = this.material;
        double unit = this.plugin.prices().buyPrice(m);
        double total = unit * this.amount;
        boolean stackable = m.getMaxStackSize() > 1;
        int shown = Math.min(this.amount, 64);
        this.set(13, ItemBuilder.of(m).amount(shown).name("<white><bold>" + TextUtil.pretty(m))
                .lore("<gray>Menge: <white>" + this.amount,
                        "<gray>Einzelpreis: <green>" + Fmt.money(unit),
                        "<gray>Gesamtpreis: <green><bold>" + Fmt.money(total),
                        "<gray>Dein Geld: <gold>" + Fmt.money(this.plugin.economy().balance((OfflinePlayer) viewer))).build());
        if (stackable) {
            int[] steps = {64, 10, 1};
            for (int i = 0; i < 3; ++i) {
                final int n = steps[i];
                this.set(9 + i, this.adjust(false, n, viewer), e -> this.change(viewer, -n));
                final int p = steps[2 - i];
                this.set(15 + i, this.adjust(true, p, viewer), e -> this.change(viewer, p));
            }
        }
        this.set(21, ItemBuilder.of(Material.RED_STAINED_GLASS_PANE).name("<red><bold>Abbrechen")
                .lore("<gray>Nichts kaufen").build(), e -> {
            Sfx.ERROR.play(viewer);
            if (this.parent != null) {
                this.parent.open(viewer);
            } else {
                viewer.closeInventory();
            }
        });
        int room = capacity(viewer, m);
        String warn = room < this.amount ? "<red>Nur " + room + " passen ins Inventar" : "";
        this.set(23, Skin.btn("confirm", ItemBuilder.of(Material.LIME_STAINED_GLASS_PANE).name("<green><bold>Kaufen")
                .lore("<gray>Menge: <white>" + this.amount, "<gray>Insgesamt: <green><bold>" + Fmt.money(total), warn, "<yellow>\u25b6 Klicken").build()), e -> {
            if (buy(this.plugin, viewer, m, this.amount) > 0 && this.parent != null) {
                this.parent.open(viewer);
            } else {
                this.refresh(viewer);
            }
        });
        int fill = capacity(viewer, m);
        this.set(25, ItemBuilder.of(Material.HOPPER).name("<green><bold>Inventar f\u00fcllen")
                .lore("<gray>Kauft so viele, wie in dein", "<gray>Inventar passen.",
                        "<gray>Menge: <white>" + fill,
                        "<gray>Kaufpreis: <green>" + Fmt.money(unit * fill), "", "<yellow>\u25b6 Klicken").build(), e -> {
            if (fill <= 0) {
                this.plugin.msg().err((CommandSender) viewer, "Dein Inventar ist voll.", new TagResolver[0]);
                Sfx.ERROR.play(viewer);
                return;
            }
            if (buy(this.plugin, viewer, m, fill) > 0 && this.parent != null) {
                this.parent.open(viewer);
            } else {
                this.refresh(viewer);
            }
        });
    }

    /** Kauft 'amount' Stück zum Shop-Preis. Liefert die tatsächlich gekaufte Menge (0 = nichts passiert). */
    static int buy(PremiumCore plugin, Player player, Material m, int amount) {
        double unit = plugin.prices().buyPrice(m);
        if (amount <= 0 || unit <= 0.0) {
            return 0;
        }
        int fit = Math.min(amount, capacity(player, m));
        if (fit <= 0) {
            plugin.msg().err((CommandSender) player, "Dein Inventar ist voll.", new TagResolver[0]);
            Sfx.ERROR.play(player);
            return 0;
        }
        double cost = unit * (double) fit;
        if (!plugin.economy().withdraw((OfflinePlayer) player, cost)) {
            plugin.msg().err((CommandSender) player, "Du brauchst <gold><cost><red>, hast aber nur <gold><bal><red>.", new TagResolver[]{Placeholder.unparsed("cost", Fmt.money(cost)), Placeholder.unparsed("bal", Fmt.money(plugin.economy().balance((OfflinePlayer) player)))});
            Sfx.ERROR.play(player);
            return 0;
        }
        int remaining = fit;
        int max = m.getMaxStackSize();
        int notFit = 0;
        while (remaining > 0) {
            int part = Math.min(max, remaining);
            HashMap<Integer, ItemStack> left = player.getInventory().addItem(new ItemStack[]{new ItemStack(m, part)});
            int back = left.values().stream().mapToInt(ItemStack::getAmount).sum();
            notFit += back;
            remaining -= part;
        }
        if (notFit > 0) {
            plugin.economy().deposit((OfflinePlayer) player, unit * (double) notFit);
        }
        int bought = fit - notFit;
        if (bought <= 0) {
            Sfx.ERROR.play(player);
            return 0;
        }
        player.sendActionBar(plugin.msg().prefixed(player, "<green>Gekauft: <white><n>x <item> <dark_gray>\u00b7 <red>-<cost>", new TagResolver[]{Placeholder.unparsed("n", String.valueOf(bought)), Placeholder.component("item", (ComponentLike) Component.translatable(m.translationKey())), Placeholder.unparsed("cost", Fmt.money(unit * (double) bought))}));
        plugin.logs().log(LogService.PLAYER, "BUY", player.getUniqueId().toString(), player.getName(), null, null, unit * (double) bought, bought, "Shop", m.name());
        Sfx.SUCCESS.play(player, 1.3f);
        return bought;
    }
}
