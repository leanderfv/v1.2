package dev.premium.core.modules.shop;

import dev.premium.core.PremiumCore;
import dev.premium.core.gui.Gui;
import dev.premium.core.service.ShopCategory;
import dev.premium.core.util.Fmt;
import dev.premium.core.util.ItemBuilder;
import dev.premium.core.util.Msg;
import dev.premium.core.util.Skin;
import dev.premium.core.util.Ui;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.entity.Player;

public final class ShopMainGui extends Gui {
    public ShopMainGui(PremiumCore plugin) {
        super(plugin, Ui.shop("Shop"), 3);
    }

    /** Anzahl Zeilen je nach Zahl der Kategorien (7 pro Zeile, mind. 4 Zeilen, max. 6). */
    static int rowsFor(PremiumCore plugin) {
        int n = plugin.prices().categories().size();
        int k = Math.max(1, (n + 6) / 7);
        return Math.min(6, k + 3);
    }

    /** Slot der i-ten Kategorie (zentriert in der letzten Zeile). */
    static int slotFor(int index, int total) {
        int row = index / 7;
        int col = index % 7;
        int inRow = Math.min(7, total - row * 7);
        int offset = (7 - inRow) / 2;
        return (1 + row) * 9 + 1 + offset + col;
    }

    private int page;

    @Override
    protected void render(Player viewer) {
        List<ShopCategory> categories = this.plugin.prices().categories();
        int per = 7;
        int pages = Math.max(1, (categories.size() + per - 1) / per);
        this.page = Math.min(this.page, pages - 1);
        int from = this.page * per;
        int count = Math.max(0, Math.min(per, categories.size() - from));
        int offset = (per - count) / 2;
        for (int i = 0; i < count; ++i) {
            ShopCategory category = categories.get(from + i);
            Material icon = Material.matchMaterial(category.iconMaterial());
            int n = this.plugin.prices().shopItems(category).size();
            this.set(10 + offset + i, ItemBuilder.of(icon != null ? icon : Material.CHEST)
                    .name(category.color() + "<bold>" + Msg.esc(category.display()))
                    .lore("<gray>" + Fmt.number((long) n) + " Items", "", "<yellow>\u25b6 Klicken zum \u00d6ffnen").build(),
                    e -> new ShopCategoryGui(this.plugin, category, this).open(viewer));
        }
        if (this.page > 0) {
            this.set(18, Skin.btn("prev", ItemBuilder.of(Material.SPECTRAL_ARROW).name("<green>\u00ab Vorherige Seite").build()), e -> {
                --this.page;
                this.refresh(viewer);
            });
        }
        if (this.page < pages - 1) {
            this.set(26, Skin.btn("next", ItemBuilder.of(Material.SPECTRAL_ARROW).name("<green>N\u00e4chste Seite \u00bb").build()), e -> {
                ++this.page;
                this.refresh(viewer);
            });
        }
    }
}
