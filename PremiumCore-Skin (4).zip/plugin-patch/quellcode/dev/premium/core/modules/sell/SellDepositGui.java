package dev.premium.core.modules.sell;

import dev.premium.core.PremiumCore;
import dev.premium.core.gui.Gui;
import dev.premium.core.gui.Interactive;
import dev.premium.core.gui.ValueView;
import dev.premium.core.util.Fmt;
import dev.premium.core.util.ItemBuilder;
import dev.premium.core.util.Skin;
import dev.premium.core.util.Ui;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.ItemStack;

/**
 * "Items verkaufen": Der Spieler legt (Shift-Klick oder Ziehen) beliebig viele Items in die freien Slots und
 * klickt unten rechts auf den grünen Haken. Nicht verkaufbare Items bleiben liegen und werden beim Schließen
 * zurückgegeben.
 */
public final class SellDepositGui extends Gui implements Interactive, ValueView {
    static final int CHECK = 35;
    private final SellModule module;
    private final Gui parent;
    private final List<Integer> slots = new ArrayList<Integer>();

    public SellDepositGui(PremiumCore plugin, SellModule module, Gui parent) {
        super(plugin, Ui.sell("Items verkaufen"), 4);
        this.module = module;
        this.parent = parent;
        for (int i = 0; i < CHECK; ++i) {
            this.slots.add(i);
        }
    }

    @Override
    protected void render(Player viewer) {
        this.button(viewer);
    }

    private void button(Player viewer) {
        SellModule.Preview p = this.module.preview(viewer, this.getInventory(), this.slots);
        ItemBuilder b = ItemBuilder.of(Material.LIME_CONCRETE).name("<green><bold>✔ Verkaufen");
        if (p.stacks > 0) {
            b.lore("<gray>Stacks: <white>" + Fmt.number((long) p.stacks) + " <dark_gray>· <gray>Items: <white>" + Fmt.number((long) p.items),
                    "<gray>Erlös: <green><bold>+" + Fmt.money(p.total),
                    p.skipped > 0 ? "<dark_gray>" + p.skipped + " Stack(s) nicht verkaufbar" : "",
                    "",
                    "<yellow>▶ Klicken zum Verkaufen").glow();
        } else {
            b.lore("<gray>Lege Items in die freien Slots", "<gray>und klicke dann hier.", "",
                    "<dark_gray>Tipp: Shift-Klick auf ein Item", "<dark_gray>in deinem Inventar");
        }
        this.set(CHECK, Skin.btn("confirm", b.build()), e -> {
            double total = this.module.sellSlots(viewer, this.getInventory(), this.slots, "Fenster");
            this.changed(viewer);
            if (total <= 0.0) {
                return;
            }
        });
    }

    // ------------------------------------------------------------------ Interaktion

    @Override
    public boolean allowClick(Player player, InventoryClickEvent event) {
        if (event.getAction() == InventoryAction.COLLECT_TO_CURSOR) {
            return false;
        }
        int raw = event.getRawSlot();
        if (raw < 0 || raw == CHECK) {
            return false;
        }
        return true;
    }

    @Override
    public boolean allowDrag(Player player, InventoryDragEvent event) {
        for (int raw : event.getRawSlots()) {
            if (raw == CHECK) {
                return false;
            }
        }
        return true;
    }

    @Override
    public void changed(Player player) {
        if (player.isOnline() && player.getOpenInventory().getTopInventory() == this.getInventory()) {
            this.button(player);
        }
    }

    @Override
    public void onClose(Player player) {
        // ESC / Schließen = automatisch verkaufen (Wert berechnen, auszahlen, Item entfernen, Nachricht + Sound)
        if (this.plugin.getConfig().getBoolean("sell.sell-on-close", true)) {
            try {
                boolean any = false;
                for (int slot : this.slots) {
                    ItemStack it = this.getInventory().getItem(slot);
                    if (it != null && !it.getType().isAir()) {
                        any = true;
                        break;
                    }
                }
                if (any) {
                    this.module.sellSlots(player, this.getInventory(), this.slots, "Fenster (ESC)");
                }
            } catch (RuntimeException ex) {
                this.plugin.getLogger().warning("Auto-Verkauf beim Schließen fehlgeschlagen: " + ex);
            }
        }
        for (int slot : this.slots) {
            ItemStack item = this.getInventory().getItem(slot);
            if (item != null && !item.getType().isAir()) {
                this.getInventory().setItem(slot, null);
                Ui.give(player, item);
            }
        }
    }
}
