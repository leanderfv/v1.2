package dev.premium.core.util;

import dev.premium.core.PremiumCore;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.function.Function;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

/**
 * Texteingabe über ein Amboss-Menü. Der Spieler tippt oben den Text ein, im Ergebnis-Slot sieht er eine
 * Vorschau und bestätigt per Klick. Funktioniert ohne NMS (Paper MenuType-API per Reflection); wenn das nicht
 * geht, wird automatisch auf die Chat-Eingabe ausgewichen.
 */
public final class AnvilPrompt implements Listener {
    private static AnvilPrompt instance;

    private final PremiumCore plugin;
    private final Map<UUID, Session> sessions = new ConcurrentHashMap<UUID, Session>();
    private boolean warned;

    private static final class Session {
        final String hint;
        final ItemStack icon;
        final Function<String, List<String>> check;
        final Consumer<String> onConfirm;
        final Runnable onCancel;
        volatile boolean done;
        volatile boolean opened;
        InventoryView view;

        Session(String hint, ItemStack icon, Function<String, List<String>> check, Consumer<String> onConfirm, Runnable onCancel) {
            this.hint = hint;
            this.icon = icon;
            this.check = check;
            this.onConfirm = onConfirm;
            this.onCancel = onCancel;
        }
    }

    private AnvilPrompt(PremiumCore plugin) {
        this.plugin = plugin;
        Bukkit.getPluginManager().registerEvents((Listener) this, (Plugin) plugin);
    }

    /** true, wenn der Spieler gerade eine Amboss-Eingabe offen hat. */
    public static boolean active(Player player) {
        AnvilPrompt i = instance;
        return i != null && i.sessions.containsKey(player.getUniqueId());
    }

    public static synchronized AnvilPrompt get(PremiumCore plugin) {
        if (instance == null || instance.plugin != plugin) {
            instance = new AnvilPrompt(plugin);
        }
        return instance;
    }

    /**
     * @param title     Titel des Amboss-Fensters (MiniMessage)
     * @param hint      Kurzer Hinweistext (z. B. "1000, 1k, 10k, 100m")
     * @param icon      Item, das im Ergebnis-Slot als Vorschau gezeigt wird (darf null sein)
     * @param check     liefert null/leer = ungültig; erste Zeile mit "!" = Fehler (rot); sonst Bezeichnung + Lore-Zeilen
     * @param onConfirm wird mit dem eingegebenen Text aufgerufen (Hauptthread)
     * @param onCancel  wird aufgerufen, wenn das Fenster ohne Bestätigung geschlossen wird (darf null sein)
     */
    public void ask(Player player, String title, String hint, ItemStack icon, Function<String, List<String>> check,
                    Consumer<String> onConfirm, Runnable onCancel) {
        title = dev.premium.core.i18n.Tr.s(player, title);
        hint = dev.premium.core.i18n.Tr.s(player, hint);
        Session old = sessions.remove(player.getUniqueId());
        if (old != null && !old.done && old.onCancel != null) {
            old.onCancel.run();
        }
        Session s = new Session(hint, icon, check, onConfirm, onCancel);
        sessions.put(player.getUniqueId(), s);
        boolean ok = false;
        try {
            ok = open(player, title, s);
        } catch (Throwable ex) {
            if (!warned) {
                warned = true;
                plugin.getLogger().warning("Amboss-Eingabe nicht verfügbar, nutze Chat-Eingabe: " + ex);
            }
        }
        if (!ok) {
            sessions.remove(player.getUniqueId());
            chatFallback(player, hint, check, onConfirm, onCancel);
        }
    }

    private void chatFallback(Player player, String hint, Function<String, List<String>> check, Consumer<String> onConfirm, Runnable onCancel) {
        plugin.prompts().ask(player, hint, text -> {
            List<String> info = check.apply(text.trim());
            if (info == null || info.isEmpty() || info.get(0).startsWith("!")) {
                String why = info == null || info.isEmpty() ? "Ungültige Eingabe." : info.get(0).substring(1);
                plugin.msg().err((CommandSender) player, why, new TagResolver[0]);
                Sfx.ERROR.play(player);
                if (onCancel != null) {
                    onCancel.run();
                }
                return;
            }
            onConfirm.accept(text.trim());
        }, onCancel);
    }

    // ------------------------------------------------------------------ Öffnen (Reflection)

    private boolean open(Player player, String title, Session s) throws Exception {
        Object view = null;
        boolean alreadyOpen = false;
        try {
            view = viaMenuType(player, title);
        } catch (Throwable ex) {
            view = null;
        }
        if (view == null) {
            Method m = HumanEntity.class.getMethod("openAnvil", Location.class, boolean.class);
            view = m.invoke(player, null, Boolean.TRUE);
            alreadyOpen = view != null;
        }
        if (!(view instanceof InventoryView)) {
            return false;
        }
        InventoryView iv = (InventoryView) view;
        s.view = iv;
        Inventory top = iv.getTopInventory();
        top.setItem(0, ItemBuilder.of(Material.PAPER).name(" ").build());
        top.setItem(2, result(s, ""));
        if (!alreadyOpen) {
            player.openInventory(iv);
        }
        s.opened = true;
        Sfx.OPEN.play(player);
        Bukkit.getScheduler().runTask((Plugin) plugin, () -> {
            if (s.opened && !s.done) {
                try {
                    iv.getTopInventory().setItem(2, result(s, ""));
                    setRepairCost(iv);
                } catch (Throwable ignored) {
                    // egal
                }
            }
        });
        return true;
    }

    private static Object viaMenuType(Player player, String title) throws Exception {
        Class<?> menuType = Class.forName("org.bukkit.inventory.MenuType");
        Object anvil = menuType.getField("ANVIL").get(null);
        Object builder = call(anvil, "org.bukkit.inventory.MenuType$Typed", "builder", new Class<?>[0]);
        Component shown = Msg.mm(title, new TagResolver[0]);
        if (Skin.enabled()) {
            shown = Skin.anvilTitle(shown, Skin.Theme.DEFAULT);
        }
        call(builder, "org.bukkit.inventory.view.builder.InventoryViewBuilder", "title", new Class<?>[]{Component.class}, shown);
        try {
            call(builder, "org.bukkit.inventory.view.builder.LocationInventoryViewBuilder", "checkReachable", new Class<?>[]{boolean.class}, Boolean.FALSE);
        } catch (Throwable ignored) {
            // nicht nötig, wenn die API das nicht kennt
        }
        return call(builder, "org.bukkit.inventory.view.builder.InventoryViewBuilder", "build", new Class<?>[]{HumanEntity.class}, player);
    }

    private static Object call(Object target, String iface, String name, Class<?>[] types, Object... args) throws Exception {
        Method m;
        try {
            m = Class.forName(iface).getMethod(name, types);
        } catch (Throwable ex) {
            m = target.getClass().getMethod(name, types);
        }
        try {
            m.setAccessible(true);
        } catch (Throwable ignored) {
            // egal
        }
        return m.invoke(target, args);
    }

    private static String renameText(Object view, Object inventory) {
        try {
            Class<?> c = Class.forName("org.bukkit.inventory.view.AnvilView");
            if (c.isInstance(view)) {
                return (String) c.getMethod("getRenameText").invoke(view);
            }
        } catch (Throwable ignored) {
            // weiter
        }
        try {
            Class<?> c = Class.forName("org.bukkit.inventory.AnvilInventory");
            if (c.isInstance(inventory)) {
                return (String) c.getMethod("getRenameText").invoke(inventory);
            }
        } catch (Throwable ignored) {
            // weiter
        }
        return null;
    }

    private static void setRepairCost(Object view) {
        try {
            Class<?> c = Class.forName("org.bukkit.inventory.view.AnvilView");
            if (c.isInstance(view)) {
                c.getMethod("setRepairCost", int.class).invoke(view, 0);
            }
        } catch (Throwable ignored) {
            // egal
        }
    }

    // ------------------------------------------------------------------ Ergebnis-Item

    private ItemStack result(Session s, String text) {
        String t = text == null ? "" : text.trim();
        Material base = s.icon != null ? s.icon.getType() : Material.EMERALD;
        if (t.isEmpty()) {
            return Skin.icon("rules/scroll", ItemBuilder.of(Material.PAPER).name("<yellow><bold>Eingabe: " + s.hint)
                    .lore("<gray>Tippe oben im Textfeld deine Eingabe,", "<gray>dann klicke hier zum Bestätigen.").build());
        }
        List<String> info = s.check.apply(t);
        if (info == null || info.isEmpty()) {
            return Skin.btn("close", ItemBuilder.of(Material.BARRIER).name("<red><bold>Ungültige Eingabe")
                    .lore("<gray>Beispiele: <white>" + s.hint).build());
        }
        String first = info.get(0);
        List<String> rest = info.subList(1, info.size());
        if (first.startsWith("!")) {
            return Skin.btn("close", ItemBuilder.of(Material.BARRIER).name("<red><bold>" + first.substring(1)).lore(rest).build());
        }
        java.util.ArrayList<String> lore = new java.util.ArrayList<String>(rest);
        lore.add("");
        lore.add("<yellow>▶ Klicken zum Bestätigen");
        return Skin.btn("confirm", ItemBuilder.of(base).name("<green><bold>✔ " + first).lore(lore).glow().build());
    }

    // ------------------------------------------------------------------ Events

    private Session sessionOf(HumanEntity who) {
        return who == null ? null : sessions.get(who.getUniqueId());
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPrepare(PrepareAnvilEvent event) {
        Session s = sessionOf(event.getView().getPlayer());
        if (s == null || !s.opened) {
            return;
        }
        String text = renameText(event.getView(), event.getInventory());
        event.setResult(dev.premium.core.i18n.Tr.item(result(s, text), event.getView().getPlayer()));
        setRepairCost(event.getView());
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onClick(InventoryClickEvent event) {
        Session s = sessionOf(event.getWhoClicked());
        if (s == null || !s.opened) {
            return;
        }
        if (event.getView().getTopInventory().getType() != InventoryType.ANVIL) {
            return;
        }
        event.setCancelled(true);
        if (event.getRawSlot() != 2 || s.done || !(event.getWhoClicked() instanceof Player)) {
            return;
        }
        Player player = (Player) event.getWhoClicked();
        String text = renameText(event.getView(), event.getView().getTopInventory());
        String t = text == null ? "" : text.trim();
        List<String> info = t.isEmpty() ? null : s.check.apply(t);
        if (info == null || info.isEmpty() || info.get(0).startsWith("!")) {
            Sfx.ERROR.play(player);
            return;
        }
        s.done = true;
        Sfx.SUCCESS.play(player);
        Bukkit.getScheduler().runTask((Plugin) plugin, () -> {
            player.closeInventory();
            s.onConfirm.accept(t);
        });
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDrag(InventoryDragEvent event) {
        Session s = sessionOf(event.getWhoClicked());
        if (s != null && s.opened && event.getView().getTopInventory().getType() == InventoryType.ANVIL) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        Session s = sessionOf(event.getPlayer());
        if (s == null || !s.opened || event.getInventory().getType() != InventoryType.ANVIL) {
            return;
        }
        Inventory inv = event.getInventory();
        inv.setItem(0, null);
        inv.setItem(1, null);
        inv.setItem(2, null);
        sessions.remove(event.getPlayer().getUniqueId());
        if (!s.done && s.onCancel != null) {
            Bukkit.getScheduler().runTask((Plugin) plugin, s.onCancel);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Session s = sessions.remove(event.getPlayer().getUniqueId());
        if (s != null && !s.done && s.onCancel != null) {
            s.onCancel.run();
        }
    }
}
