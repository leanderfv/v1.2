package dev.premium.core.util;

import dev.premium.core.PremiumCore;
import java.util.List;
import java.util.function.Function;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/** Gemeinsames Design für Shop, Sell-GUI, Auktionshaus und Admin-Editor. */
public final class Ui {
    public static final Material FRAME = Material.BLACK_STAINED_GLASS_PANE;

    private Ui() {
    }

    /** Einheitlicher Titel mit Farbverlauf. */
    public static String title(String text, String from, String to) {
        return "<gradient:" + from + ":" + to + "><bold>" + text + "</bold></gradient>";
    }

    /** Füller-Item: unsichtbar mit Resourcepack-Skin, sonst die schwarze Glasscheibe. */
    public static ItemStack pane() {
        return Skin.enabled() ? Skin.blank() : ItemBuilder.of(FRAME).name(" ").build();
    }

    public static String shop(String text) {
        return title(text, "#FFAA00", "#FF5555");
    }

    public static String sell(String text) {
        return title(text, "#55FF55", "#00AA00");
    }

    public static String auction(String text) {
        return title(text, "#55FFFF", "#5555FF");
    }

    public static String admin(String text) {
        return title(text, "#FF5555", "#FFAA00");
    }

    public static ItemStack balance(PremiumCore plugin, Player viewer) {
        double money = plugin.economy().balance((OfflinePlayer) viewer);
        ItemBuilder b = ItemBuilder.of(Material.GOLD_INGOT)
                .name("<gold><bold>Dein Geld")
                .lore("<green><bold>" + Skin.shortMoney(money) + "$", "<gray>Exakt: <white>" + Fmt.money(money))
                .glow();
        return Skin.icon("money/coins", b.build());
    }

    public static String money(double v) {
        return "<green>" + Fmt.money(v);
    }

    /** Pr\u00fcfer f\u00fcr Geldbetrag-Eingaben (1000, 1k, 10k, 100m ...) im Amboss-Men\u00fc. */
    public static Function<String, List<String>> moneyCheck(double min, double max) {
        return t -> {
            double v = Amounts.parse(t);
            if (Double.isNaN(v)) {
                return List.of("!Ung\u00fcltiger Betrag");
            }
            if (v < min) {
                return List.of("!Mindestens " + Fmt.money(min));
            }
            if (v > max) {
                return List.of("!H\u00f6chstens " + Fmt.money(max));
            }
            return List.of(Fmt.money(v));
        };
    }

    /** Gibt dem Spieler ein Item (Rest, der nicht ins Inventar passt, wird vor ihm fallen gelassen). */
    public static void give(Player player, ItemStack item) {
        if (item == null || item.getType().isAir()) {
            return;
        }
        java.util.HashMap<Integer, ItemStack> left = player.getInventory().addItem(new ItemStack[]{item});
        for (ItemStack rest : left.values()) {
            player.getWorld().dropItem(player.getLocation(), rest);
        }
    }
}
