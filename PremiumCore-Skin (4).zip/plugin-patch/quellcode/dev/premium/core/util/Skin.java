package dev.premium.core.util;

import dev.premium.core.PremiumCore;
import dev.premium.core.gui.Gui;
import java.util.Set;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.ShadowColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/**
 * Resourcepack-Skin für alle GUIs: Hintergrund per Titel-Glyph (Font premium:gui), Buttons per item_model.
 * Muss zu den Dateien aus dem Pack passen (generate.py). Ohne das Pack: config.yml -> skin.enabled: false.
 */
public final class Skin {
    public enum Layout { PLAIN, BAR, RING, FRAME, SCROLL }

    /** Reihenfolge = Reihenfolge der Plaketten im Pack. */
    public enum Theme {
        DEFAULT("#e6edf7"), SHOP("#ffe2a8"), SELL("#d6ffc8"), AUCTION("#d0f7ff"), ORDERS("#d3e6ff"), ADMIN("#ffd0d0"), CRATES("#f0d4ff"), GOLD("#fff4b8");

        final TextColor text;

        Theme(String hex) {
            this.text = TextColor.fromHexString(hex);
        }
    }

    private static final Key FONT = Key.key("premium", "gui");
    private static final Key VANILLA = Key.key("minecraft", "default");
    /** Vorschub eines Bitmap-Glyphs = Breite + 1 (Minecraft-Regel). Bei 1px-Versatz hier anpassen. */
    private static final int PAD = 1;
    private static final int BG_WIDTH = 176 + PAD;
    private static final int[] PLAQUE_W = {100, 140, 164};
    private static final Set<String> SHOP_FRAME = Set.of("ShopMainGui", "ShopCategoryGui", "BuyGui");
    private static final Set<String> ADMIN_CRATE = Set.of("CrateAdminGui", "CrateEditGui", "RewardEditGui", "AddRewardGui", "CrateRewardsGui");

    private Skin() {
    }

    public static boolean enabled() {
        try {
            return PremiumCore.getPlugin(PremiumCore.class).getConfig().getBoolean("skin.enabled", true);
        } catch (Throwable t) {
            return false;
        }
    }

    // ------------------------------------------------------------------ Items

    /** Unsichtbarer Füller (statt Glasscheiben). */
    public static ItemStack blank() {
        ItemStack item = new ItemStack(Material.GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        meta.setItemModel(new NamespacedKey("premium", "blank"));
        meta.setHideTooltip(true);
        meta.displayName(Component.space());
        item.setItemMeta(meta);
        return item;
    }

    public static final char ICON_COIN = '\uE400', ICON_STAR = '\uE401', ICON_SWORD = '\uE402', ICON_SKULL = '\uE403', ICON_CROWN = '\uE404',
            ICON_KEY = '\uE405', ICON_CLOCK = '\uE406', ICON_SIGNAL = '\uE407', ICON_GEM = '\uE408', ICON_PEOPLE = '\uE409', ICON_SHIELD = '\uE40A', DIVIDER = '\uE440', FRAME = '\uE500';

    /** Vorschub eines Icons (9 oder 10 px): Stern und Schild sind 9 px breit, alle anderen 8 px. */
    public static int iconAdvance(char c) {
        return c == ICON_STAR || c == ICON_SHIELD ? 10 : 9;
    }

    /** Ein Glyph aus dem Pack als Text-Komponente (Icons im Scoreboard u. ä.). */
    public static Component glyph(char c) {
        return Component.text(String.valueOf(c)).font(FONT).color(NamedTextColor.WHITE).shadowColor(ShadowColor.none());
    }

    /** Leerraum in Pixeln (auch negativ). */
    public static Component space(int px) {
        return Component.text(shift(px)).font(FONT);
    }

    /** Tooltip-Stil aus dem Pack (Hintergrund + Rahmen in der Farbe des Bereichs). */
    public static ItemStack style(ItemStack item, Theme theme) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }
        meta.setTooltipStyle(new NamespacedKey("premium", theme.name().toLowerCase(java.util.Locale.ROOT)));
        item.setItemMeta(meta);
        return item;
    }

    /** 326350000 -> 326.35M, 1500 -> 1.5K */
    public static String shortMoney(double v) {
        double a = Math.abs(v);
        String[] suffix = {"", "K", "M", "B", "T", "Q"};
        int i = 0;
        double x = a;
        while (x >= 1000.0 && i < suffix.length - 1) {
            x /= 1000.0;
            ++i;
        }
        String num = new java.text.DecimalFormat("0.##", java.text.DecimalFormatSymbols.getInstance(java.util.Locale.US)).format(x);
        return (v < 0 ? "-" : "") + num + suffix[i];
    }

    /** Beliebiges Pack-Icon (premium:<pfad>), z. B. "rules/book". */
    public static ItemStack icon(String path, ItemStack item) {
        if (!enabled() || item == null) {
            return item;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }
        meta.setItemModel(new NamespacedKey("premium", path));
        item.setItemMeta(meta);
        return item;
    }

    /** Button-Textur aus dem Pack (refresh, search, prev, next, filter, back, close, cancel, confirm, orders, plus, minus). */
    public static ItemStack btn(String name, ItemStack item) {
        if (!enabled() || item == null) {
            return item;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }
        meta.setItemModel(new NamespacedKey("premium", "btn/" + name));
        item.setItemMeta(meta);
        return item;
    }

    // ------------------------------------------------------------------ Zuordnung GUI -> Theme

    public static Theme themeOf(Gui gui) {
        String full = gui.getClass().getName();
        String simple = gui.getClass().getSimpleName();
        if (SHOP_FRAME.contains(simple)) return Theme.SHOP;
        if (simple.equals("RulesGui")) return Theme.GOLD;
        if (full.contains(".auction.")) return Theme.AUCTION;
        if (full.contains(".orders.")) return Theme.ORDERS;
        if (full.contains(".sell.")) return Theme.SELL;
        if (full.contains(".crate.")) return ADMIN_CRATE.contains(simple) ? Theme.ADMIN : Theme.CRATES;
        if (full.contains(".admin.") || full.contains(".rank.") || full.contains(".tracker.") || full.contains(".moderation.") || full.contains(".shop.")) return Theme.ADMIN;
        if (full.contains("Clan")) return Theme.GOLD;
        if (full.contains("Tpa")) return Theme.AUCTION;
        if (full.contains("Rtp")) return Theme.SELL;
        return Theme.DEFAULT;
    }

    // ------------------------------------------------------------------ Titel

    /** Baut den Titel: Hintergrund-Glyph, Plakette und zentrierten Text (bei FRAME nur den Rahmen + Original-Titel). */
    public static Component title(Component original, Theme theme, Layout layout, int rows) {
        char bg = (char) (0xE000 + layout.ordinal() * 6 + (rows - 1));
        if (layout == Layout.FRAME) {
            Component glyphs = Component.text(shift(-8) + bg + shift(-BG_WIDTH + 8)).font(FONT).color(NamedTextColor.WHITE).shadowColor(ShadowColor.none());
            return glyphs.append(original.font(VANILLA));
        }
        String plain = PlainTextComponentSerializer.plainText().serialize(original);
        int tw = width(plain);
        int size = tw <= 84 ? 0 : tw <= 124 ? 1 : 2;
        int pw = PLAQUE_W[size] + PAD;
        int px = (176 - PLAQUE_W[size]) / 2;
        char plaque = (char) (0xE100 + theme.ordinal() * 3 + size);
        int tx = Math.max(px + 4, (176 - tw) / 2);
        StringBuilder g = new StringBuilder();
        g.append(shift(-8)).append(bg);                  // Titel startet bei x=8 -> auf 0 zurück, Hintergrund
        g.append(shift(px - BG_WIDTH)).append(plaque);   // zurück an den Plakettenanfang
        g.append(shift(tx - px - pw));                    // zum Textanfang
        Component glyphs = Component.text(g.toString()).font(FONT).color(NamedTextColor.WHITE).shadowColor(ShadowColor.none());
        Component text = Component.text(plain).font(VANILLA).color(theme.text);
        return glyphs.append(text);
    }

    /** Titel für den Amboss-Dialog (AnvilPrompt): Hintergrund U+E300, Plakette U+E200+Theme, Titel beginnt dort bei x=60. */
    public static Component anvilTitle(Component original, Theme theme) {
        String plain = PlainTextComponentSerializer.plainText().serialize(original);
        int tw = width(plain);
        int plaqueX = 59;
        int plaqueW = 110 + PAD;
        int tx = Math.max(plaqueX + 3, plaqueX + (110 - tw) / 2);
        StringBuilder g = new StringBuilder();
        g.append(shift(-60)).append((char) 0xE300);
        g.append(shift(plaqueX - BG_WIDTH)).append((char) (0xE200 + theme.ordinal()));
        g.append(shift(tx - plaqueX - plaqueW));
        Component glyphs = Component.text(g.toString()).font(FONT).color(NamedTextColor.WHITE).shadowColor(ShadowColor.none());
        return glyphs.append(Component.text(plain).font(VANILLA).color(theme.text));
    }

    /** Negative/positive Leerräume aus dem Pack (U+F800+i = -2^i, U+F810+i = +2^i). */
    public static String shift(int px) {
        StringBuilder sb = new StringBuilder();
        int n = Math.abs(px);
        for (int i = 8; i >= 0; --i) {
            while (n >= (1 << i)) {
                sb.append((char) ((px < 0 ? 0xF800 : 0xF810) + i));
                n -= 1 << i;
            }
        }
        return sb.toString();
    }

    /** Breite von Text in der Standard-Schrift (ohne Fett). */
    public static int width(String s) {
        int w = 0;
        for (char c : s.toCharArray()) {
            w += adv(c);
        }
        return Math.max(0, w - 1);
    }

    private static int adv(char c) {
        switch (c) {
            case 'i': case '!': case '.': case ',': case ':': case ';': case '|': return 2;
            case 'l': case '\'': case '`': case '·': return 3;
            case 'I': case 't': case '[': case ']': case ' ': return 4;
            case '@': case '~': return 7;
            default: return 6;
        }
    }
}
