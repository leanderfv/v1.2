package dev.premium.core.gui;

import dev.premium.core.PremiumCore;
import dev.premium.core.util.ItemBuilder;
import dev.premium.core.util.Skin;
import java.util.List;
import java.util.function.Supplier;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public abstract class PagedGui<T> extends Gui {
    private static final int[] SLOTS = new int[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};
    private final Supplier<List<T>> source;
    private final Gui parent;
    private int page;

    protected PagedGui(PremiumCore plugin, String title, Gui parent, Supplier<List<T>> source) {
        super(plugin, title, 6);
        this.parent = parent;
        this.source = source;
    }

    protected abstract ItemStack icon(T entry);

    protected abstract void select(Player viewer, T entry, InventoryClickEvent event);

    protected void footer(Player viewer) {
    }

    protected String emptyText() {
        return "<red>Keine Einträge vorhanden";
    }

    /** Rahmenfarbe; Unterklassen können sie überschreiben. */
    protected Material frame() {
        return Material.GRAY_STAINED_GLASS_PANE;
    }

    protected final int page() {
        return this.page;
    }

    protected final void page(int page) {
        this.page = Math.max(0, page);
    }

    @Override
    protected void render(Player viewer) {
        this.border(this.frame());
        List<T> entries = this.source.get();
        int pages = Math.max(1, (int) Math.ceil((double) entries.size() / (double) SLOTS.length));
        this.page = Math.min(this.page, pages - 1);
        for (int i = 0; i < SLOTS.length; ++i) {
            int index = this.page * SLOTS.length + i;
            if (index >= entries.size()) break;
            final T entry = entries.get(index);
            this.set(SLOTS[i], this.icon(entry), e -> this.select(viewer, entry, e));
        }
        if (entries.isEmpty()) {
            this.set(22, ItemBuilder.of(Material.BARRIER).name(this.emptyText()).build());
        }
        this.set(4, ItemBuilder.of(Material.PAPER).name("<white>Seite <yellow>" + (this.page + 1) + "<gray>/<yellow>" + pages).lore("<gray>" + entries.size() + " Einträge").build());
        if (this.page > 0) {
            this.set(48, Skin.btn("prev", ItemBuilder.of(Material.SPECTRAL_ARROW).name("<green>« Vorherige Seite").build()), e -> {
                --this.page;
                this.refresh(viewer);
            });
        }
        if (this.page < pages - 1) {
            this.set(50, Skin.btn("next", ItemBuilder.of(Material.SPECTRAL_ARROW).name("<green>Nächste Seite »").build()), e -> {
                ++this.page;
                this.refresh(viewer);
            });
        }
        if (this.parent != null) {
            this.backButton(49, this.parent);
        } else {
            this.closeButton(49);
        }
        this.footer(viewer);
    }
}
