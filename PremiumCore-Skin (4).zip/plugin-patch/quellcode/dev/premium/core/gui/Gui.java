package dev.premium.core.gui;

import dev.premium.core.PremiumCore;
import dev.premium.core.i18n.Tr;
import dev.premium.core.util.ItemBuilder;
import dev.premium.core.util.Msg;
import dev.premium.core.util.Sfx;
import dev.premium.core.util.Skin;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

public abstract class Gui implements InventoryHolder {
    protected final PremiumCore plugin;
    private Inventory inventory;
    private final int rows;
    private final String title;
    private String shownTitle;
    private String shownKey;
    private boolean ring;
    private Player renderViewer;
    private final Map<Integer, Consumer<InventoryClickEvent>> actions = new HashMap<Integer, Consumer<InventoryClickEvent>>();
    private final List<Integer> borderSlots = new ArrayList<Integer>();
    private ItemStack borderItem;

    protected Gui(PremiumCore plugin, String title, int rows) {
        this.plugin = plugin;
        this.rows = rows;
        this.title = title;
        this.shownTitle = null;
        this.inventory = Bukkit.createInventory((InventoryHolder) this, rows * 9, (Component) Msg.mm(title, new TagResolver[0]));
    }

    /** false = Texte dieses Fensters nie übersetzen (z. B. die zweisprachige Sprachauswahl). */
    protected boolean translated() {
        return true;
    }

    /** Baut das Inventar mit dem Titel in der Sprache des Spielers neu auf, falls er sich vom aktuellen unterscheidet. */
    /** Optik des Fensters (Resourcepack). Unterklassen können überschreiben, z. B. BAR für eine Knopfleiste unten. */
    protected Skin.Layout layout() {
        if (Skin.themeOf(this) == Skin.Theme.SHOP) {
            return Skin.Layout.FRAME;
        }
        return this.ring ? Skin.Layout.RING : Skin.Layout.PLAIN;
    }

    private boolean skinned() {
        return Skin.enabled();
    }

    private void applyTitle(Player viewer) {
        String wanted = this.translated() ? Tr.s(viewer, this.title) : this.title;
        Skin.Layout layout = this.layout();
        String key = wanted + "|" + layout + "|" + this.skinned();
        if (key.equals(this.shownKey)) {
            return;
        }
        Component base = Msg.mm(wanted, new TagResolver[0]);
        Component shown = this.skinned() ? Skin.title(base, Skin.themeOf(this), layout, this.rows) : base;
        Inventory fresh = Bukkit.createInventory((InventoryHolder) this, this.rows * 9, shown);
        fresh.setContents(this.inventory.getContents());
        this.inventory = fresh;
        this.shownTitle = wanted;
        this.shownKey = key;
    }

    public Inventory getInventory() {
        return this.inventory;
    }

    protected abstract void render(Player viewer);

    public void refresh(Player viewer) {
        this.renderViewer = viewer;
        this.actions.clear();
        this.borderSlots.clear();
        this.borderItem = null;
        this.inventory.clear();
        this.render(viewer);
    }

    public void open(final Player viewer) {
        this.refresh(viewer);
        this.applyTitle(viewer);
        final List<Integer> slots = new ArrayList<Integer>(this.borderSlots);
        final ItemStack frame = this.borderItem;
        for (int slot : slots) {
            this.inventory.setItem(slot, null);
        }
        viewer.openInventory(this.inventory);
        Sfx.OPEN.play(viewer);
        if (frame == null || slots.isEmpty()) {
            return;
        }
        final Inventory inv = this.inventory;
        new BukkitRunnable() {
            int index = 0;

            public void run() {
                if (!viewer.isOnline() || viewer.getOpenInventory().getTopInventory() != inv) {
                    this.cancel();
                    return;
                }
                for (int i = 0; i < 2 && this.index < slots.size(); ++i) {
                    int slot = slots.get(this.index++);
                    // Slots, die inzwischen mit einem Button belegt wurden, nie überschreiben
                    if (inv.getItem(slot) == null) {
                        inv.setItem(slot, frame);
                    }
                }
                if (this.index % 8 == 0) {
                    Sfx.TICK.play(viewer, 1.0f + (float) this.index / (float) slots.size());
                }
                if (this.index >= slots.size()) {
                    this.cancel();
                }
            }
        }.runTaskTimer((Plugin) this.plugin, 1L, 1L);
    }

    public void handleClick(Player player, InventoryClickEvent event) {
        Consumer<InventoryClickEvent> action = this.actions.get(event.getRawSlot());
        if (action != null) {
            Sfx.CLICK.play(player);
            action.accept(event);
        }
    }

    public void onClose(Player player) {
    }

    /** Item in der Sprache des Betrachters (Englisch, wenn er das gewählt hat). */
    private ItemStack localized(ItemStack item) {
        return this.renderViewer != null && this.translated() ? Tr.item(item, this.renderViewer) : item;
    }

    /** Tooltip-Stil des Resourcepacks (nicht bei Fenstern, in die Spieler echte Items legen). */
    private ItemStack styled(ItemStack item) {
        if (item == null || this instanceof Interactive || !this.skinned()) {
            return item;
        }
        return Skin.style(item.clone(), Skin.themeOf(this));
    }

    protected void set(int slot, ItemStack item) {
        this.borderSlots.remove(Integer.valueOf(slot));
        this.inventory.setItem(slot, this.styled(this.localized(item)));
    }

    protected void set(int slot, ItemStack item, Consumer<InventoryClickEvent> action) {
        this.borderSlots.remove(Integer.valueOf(slot));
        this.inventory.setItem(slot, this.styled(this.localized(item)));
        this.actions.put(slot, action);
    }

    protected void border(Material pane) {
        this.ring = true;
        if (this.skinned()) {
            return; // Rahmen kommt aus dem Resourcepack
        }
        this.borderItem = ItemBuilder.of(pane).name(" ").build();
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int c = 0; c < 9; ++c) {
            order.add(c);
        }
        for (int r = 1; r < this.rows; ++r) {
            order.add(r * 9 + 8);
        }
        for (int c = 7; c >= 0; --c) {
            order.add((this.rows - 1) * 9 + c);
        }
        for (int r = this.rows - 2; r >= 1; --r) {
            order.add(r * 9);
        }
        this.borderSlots.addAll(order);
        for (int slot : order) {
            this.inventory.setItem(slot, this.borderItem);
        }
    }

    protected void fill(Material pane) {
        if (this.skinned()) {
            return;
        }
        ItemStack filler = ItemBuilder.of(pane).name(" ").build();
        for (int i = 0; i < this.inventory.getSize(); ++i) {
            if (this.inventory.getItem(i) != null) continue;
            this.inventory.setItem(i, filler);
        }
    }

    protected void closeButton(int slot) {
        this.set(slot, Skin.btn("close", ItemBuilder.of(Material.BARRIER).name("<red><bold>Schließen").build()), e -> e.getWhoClicked().closeInventory());
    }

    protected void backButton(int slot, Gui parent) {
        this.set(slot, Skin.btn("back", ItemBuilder.of(Material.ARROW).name("<yellow>« Zurück").lore("<gray>Zum vorherigen Menü").build()), e -> parent.open((Player) e.getWhoClicked()));
    }
}
