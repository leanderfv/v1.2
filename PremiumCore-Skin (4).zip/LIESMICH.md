# PremiumCore Skin (Resourcepack + Plugin-Patch)

## 1) Resourcepack einbinden
`PremiumCore-Pack.zip` irgendwo hosten (direkter Download-Link) und in der `server.properties` eintragen:

    resource-pack=https://DEIN-LINK/PremiumCore-Pack.zip
    resource-pack-sha1=<sha1 der zip>
    require-resource-pack=true
    resource-pack-prompt=Pflicht-Pack fuer die Menues

SHA-1: `sha1sum PremiumCore-Pack.zip`. `require-resource-pack=true` ist wichtig: ohne Pack sieht man kaputte Texturen.
Mindestens Minecraft 1.21.11 (Pack-Format 75), nach oben offen (getestet nur in der Vorschau, nicht im Spiel).

## 2) Plugin-Patch
Ordner `plugin-patch/quellcode/...` ueber dein Projekt kopieren (ueberschreibt Gui, PagedGui, Ui, OrdersGui,
ItemSelectGui, OrderConfirmGui, AuctionGui, ShopMainGui, ShopCategoryGui, SellDepositGui, BuyGui, CreateAuctionGui, TpaFeature, AnvilPrompt (Texteingabe-Dialog), OnboardingFeature (Regelwerk + Sprachwahl), ExtrasModule (/rules oeffnet das Menue); neu: util/Skin.java).
Den Block aus `config.yml-ANHANG.txt` ans Ende der config.yml. Dann wie gewohnt bauen.
`skin.enabled: false` schaltet das alte Aussehen (Glasscheiben) wieder ein.
Nicht kompiliert (Paper-API/Teile des Projekts fehlen hier) - bei Fehlern Meldung schicken.

## 3) Wie es funktioniert
- Hintergrund = Glyph im Inventar-Titel (Font `premium:gui`), Plakette mit zentriertem Titel.
- Layouts: PLAIN (alles Slots), BAR (unterste Reihe = Knopfleiste: Orders, Auktionshaus, Bestaetigen),
  RING (alle GUIs mit `border(...)`: Rand grau, innen dunkel), FRAME (Shop: nur Umrandung, Rest Vanilla).
- Farben pro Bereich: Auktion cyan, Orders blau, Sell gruen, Admin/Raenge rot, Crates lila, Clans gold.
- Buttons = Item-Modelle `premium:btn/<name>`; Glasscheiben-Fueller sind unsichtbar (`premium:blank`).
- Eigene Buttons: `Skin.btn("refresh", item)` (refresh, search, prev, next, filter, back, close, cancel, confirm, orders, plus, minus).
- Eigenes Layout fuer ein GUI: in der Klasse `layout()` ueberschreiben. Theme-Zuordnung: `Skin.themeOf`.
- Texturen: `PremiumCore-Pack.zip` ist jetzt dein eigener Stand (Pack_8). Der Generator ist entfernt, damit er deine Aenderungen nicht ueberschreibt.

## Nachtrag: Scoreboard, Tooltips, Amboss
- Scoreboard: eigene Icons, Werte-Spalte, Trennlinien (`scoreboard.skin: false` in der config.yml schaltet es ab).
- Tooltips: Items in Menues bekommen einen dunklen Tooltip mit Rahmen in der Bereichsfarbe.
- Amboss: Textfeld ist ein Loch im Hintergrund, damit man die Eingabe sieht. Das Pack ueberschreibt dafuer das Vanilla-Sprite
  `container/anvil/text_field` (dunkles Feld) - das gilt auch fuer normale Ambosse.
- Dein-Geld-Item: Muenzen-Icon, Kurzform (100T) und exakter Betrag.

- Scoreboard nutzt `font/sb/frame.png` (U+E500) als Rahmen im Titel und die 11 Icons aus `font/icons.png` (Reihenfolge: Geld, Level, Kills, Tode, Clan, Keyall, Spielzeit, Ping, XP, Online, Schild=U+E40A, noch ungenutzt).
- Neue Button-Texturen aus deinem Pack (`arrow_right`, `arrow_right_off`, `hand`, `info`, `question`) gehen sofort ueber `Skin.btn("name", item)`.
